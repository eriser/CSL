var _shoe_box_8cpp =
[
    [ "SPEED_OF_SOUND", "_shoe_box_8cpp.html#ac9f9f9d25bbf964365102f1ef77d359e", null ],
    [ "kWoodCoefficient", "_shoe_box_8cpp.html#a7eeadeb0b9d687f3883768272e0a2f45", null ],
    [ "kMarbleCoefficient", "_shoe_box_8cpp.html#a11c48f4c5a5da43acfa8f89c06ca9a61", null ],
    [ "kConcreteCoefficient", "_shoe_box_8cpp.html#a9e02bc2cbe29e2506aa3600ab929fbc7", null ],
    [ "kBrockCoefficient", "_shoe_box_8cpp.html#ab73036eec9dbb2d35daeedd79dacd17f", null ],
    [ "kGlassCoefficient", "_shoe_box_8cpp.html#a5c88c99b28138f06c624ae225f26f0de", null ]
];