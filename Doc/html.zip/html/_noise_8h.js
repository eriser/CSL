var _noise_8h =
[
    [ "Noise", "classcsl_1_1_noise.html", "classcsl_1_1_noise" ],
    [ "WhiteNoise", "classcsl_1_1_white_noise.html", "classcsl_1_1_white_noise" ],
    [ "PinkNoise", "classcsl_1_1_pink_noise.html", "classcsl_1_1_pink_noise" ],
    [ "PINK_MAX_RANDOM_ROWS", "_noise_8h.html#aacad2d0d75b07d001133a8227bb16a09", null ],
    [ "PINK_RANDOM_BITS", "_noise_8h.html#a543ce37e1e5c7fde4ec39c832136683c", null ],
    [ "PINK_RANDOM_SHIFT", "_noise_8h.html#a2bc95aedc61109291640be3c2847d21d", null ]
];