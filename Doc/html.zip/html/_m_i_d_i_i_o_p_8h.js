var _m_i_d_i_i_o_p_8h =
[
    [ "CSL_MIDIMessage", "classcsl_1_1_c_s_l___m_i_d_i_message.html", "classcsl_1_1_c_s_l___m_i_d_i_message" ],
    [ "MIDIIO", "classcsl_1_1_m_i_d_i_i_o.html", "classcsl_1_1_m_i_d_i_i_o" ],
    [ "MIDIIn", "classcsl_1_1_m_i_d_i_in.html", "classcsl_1_1_m_i_d_i_in" ],
    [ "MIDIOut", "classcsl_1_1_m_i_d_i_out.html", "classcsl_1_1_m_i_d_i_out" ],
    [ "OUTPUT_BUFFER_SIZE", "_m_i_d_i_i_o_p_8h.html#a29a61474854edfeed19457644161249f", null ],
    [ "DRIVER_INFO", "_m_i_d_i_i_o_p_8h.html#a1570fe90226fc68d1ade00a6c9e4b488", null ],
    [ "TIME_PROC", "_m_i_d_i_i_o_p_8h.html#a4460e8d4c983fc90645b607d0afd22f6", null ],
    [ "TIME_INFO", "_m_i_d_i_i_o_p_8h.html#ae655527dbf5a174e53f96a206729c208", null ],
    [ "TIME_START", "_m_i_d_i_i_o_p_8h.html#a478746a56a0f0a831302083552ba2062", null ],
    [ "MIDI_THRU", "_m_i_d_i_i_o_p_8h.html#a6ce86ae1e6c00de7a80c3a74be8cc08a", null ],
    [ "CSL_MIDIMessageType", "_m_i_d_i_i_o_p_8h.html#a8d0bb7b7a5b1a54cbd43e67d48c555d6", [
      [ "kNone", "_m_i_d_i_i_o_p_8h.html#a8d0bb7b7a5b1a54cbd43e67d48c555d6a83dda44f162ccaf5438501871d11858a", null ],
      [ "kNoteOff", "_m_i_d_i_i_o_p_8h.html#a8d0bb7b7a5b1a54cbd43e67d48c555d6a6d5a304742bc4bf86303029b6d37280a", null ],
      [ "kNoteOn", "_m_i_d_i_i_o_p_8h.html#a8d0bb7b7a5b1a54cbd43e67d48c555d6a55823aff06d70659325a9c1553f2578e", null ],
      [ "kPolyTouch", "_m_i_d_i_i_o_p_8h.html#a8d0bb7b7a5b1a54cbd43e67d48c555d6aa6bd08fdcd09750f381c287c389b1512", null ],
      [ "kControlChange", "_m_i_d_i_i_o_p_8h.html#a8d0bb7b7a5b1a54cbd43e67d48c555d6a4c612d4ccc054b9f1705e52f6fc6bda1", null ],
      [ "kProgramChange", "_m_i_d_i_i_o_p_8h.html#a8d0bb7b7a5b1a54cbd43e67d48c555d6accc1122101e17bcc7ce97b91691e3a79", null ],
      [ "kAftertouch", "_m_i_d_i_i_o_p_8h.html#a8d0bb7b7a5b1a54cbd43e67d48c555d6a137fb0579bb424dc00226cacb1755385", null ],
      [ "kPitchWheel", "_m_i_d_i_i_o_p_8h.html#a8d0bb7b7a5b1a54cbd43e67d48c555d6a8d5c7e2211997228e6250cecb1572ab7", null ],
      [ "kSysEX", "_m_i_d_i_i_o_p_8h.html#a8d0bb7b7a5b1a54cbd43e67d48c555d6aa33126e67683b9b679c39b15fced1927", null ]
    ] ],
    [ "copy_CSL_MIDIMessage", "_m_i_d_i_i_o_p_8h.html#abea5ad4204ba302b456e4e23fb7cb5e0", null ],
    [ "CSL_MIDIMessageToPmEvent", "_m_i_d_i_i_o_p_8h.html#abb40606ce15868fb182b53ccb61574cd", null ],
    [ "PmEventToCSL_MIDIMessage", "_m_i_d_i_i_o_p_8h.html#a50169416ae8c22af2ee26f43b0adac94", null ],
    [ "Message_ChannelToStatus", "_m_i_d_i_i_o_p_8h.html#a9566760d3ab76504407536ca36b01e58", null ]
];