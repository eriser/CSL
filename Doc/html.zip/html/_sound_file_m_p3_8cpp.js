var _sound_file_m_p3_8cpp =
[
    [ "vbuffer", "structvbuffer.html", "structvbuffer" ],
    [ "DEFAULT_MP3_RATE", "_sound_file_m_p3_8cpp.html#ad36f7b255c86e860944e5f500c3931d1", null ],
    [ "MP3_SAMP_TYPE", "_sound_file_m_p3_8cpp.html#ad88a8bbc7dec634b50859f5ab53dd494", null ],
    [ "MP3_WRITE", "_sound_file_m_p3_8cpp.html#aaf428e5ca9b0da01c354df063da0905f", null ],
    [ "MP3_DEPTH", "_sound_file_m_p3_8cpp.html#ac23e8d7b5b5c136b99dfa8cab8b00783", null ],
    [ "scale_MP3F", "_sound_file_m_p3_8cpp.html#a44b2be129a43789c67a45c85ac063718", null ],
    [ "scale_MP3", "_sound_file_m_p3_8cpp.html#acb3ef1c7178df40e185d83a958d45e58", null ],
    [ "close_file", "_sound_file_m_p3_8cpp.html#a7e00fb8f2df73f0c1028ed4873595842", null ],
    [ "m3_input", "_sound_file_m_p3_8cpp.html#a083e10c7ca45e2539214cbbee5392309", null ],
    [ "m3_output", "_sound_file_m_p3_8cpp.html#a550813b1fc26378f99b5805d24beddd7", null ],
    [ "m3_error", "_sound_file_m_p3_8cpp.html#aeaf7554d546abce4d81cf064ca01804f", null ],
    [ "m3_header", "_sound_file_m_p3_8cpp.html#ae53699cabdfc79ca492efc0301eed205", null ]
];