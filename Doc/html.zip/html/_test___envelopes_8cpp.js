var _test___envelopes_8cpp =
[
    [ "USE_TEST_MAIN", "_test___envelopes_8cpp.html#a8cb66fa186ca4331bbdb9c15a8c89117", null ],
    [ "BASE_FREQ", "_test___envelopes_8cpp.html#a25cc638ebb9c29f5ea0a545454c50d31", null ],
    [ "testGliss", "_test___envelopes_8cpp.html#a5e4927847df489d3e3546c18c52fbab2", null ],
    [ "testSwell", "_test___envelopes_8cpp.html#a00487c4bee34dccb5e81506dd1faa615", null ],
    [ "testARSin", "_test___envelopes_8cpp.html#a445e4ce3562d9cbefbcf90779060476e", null ],
    [ "testARSin2", "_test___envelopes_8cpp.html#af5ac67b9cca3e32ffb50982aa9aa9abf", null ],
    [ "testFrequencyEnv", "_test___envelopes_8cpp.html#a742f3fcac000904ae4465da0dd61c78e", null ],
    [ "testAMFMEnvs", "_test___envelopes_8cpp.html#a626c10b652e7b6e15f66fe7ef36a987f", null ],
    [ "testADSR2", "_test___envelopes_8cpp.html#a45be0faf8e46f63c3f914b3c2fb69a81", null ],
    [ "testADSR_FM", "_test___envelopes_8cpp.html#ab128e070e76f1d0c2a190a82b791fa2f", null ],
    [ "testRandFreqEnv", "_test___envelopes_8cpp.html#a68514e7ec33b00bcf0f4a62bbdf5c354", null ],
    [ "createRandFreqEnvPatch", "_test___envelopes_8cpp.html#ace4c6f1b503dccf443c2dc63cb708ac5", null ],
    [ "test50RandFreqEnv", "_test___envelopes_8cpp.html#a15e3362d827619c28f966c31414f55e7", null ],
    [ "testEnvScale", "_test___envelopes_8cpp.html#aa3b38d49f37b2739e8d93314517e3c05", null ],
    [ "testFancy_FM", "_test___envelopes_8cpp.html#add4501bfc702f9a5e9a99579530b7abf", null ],
    [ "testComplexEnvelope", "_test___envelopes_8cpp.html#a465551551807c226b4f1288733acafe1", null ],
    [ "sosNote", "_test___envelopes_8cpp.html#a6b3ba9c9fee2b034af4435b888f03f4b", null ],
    [ "testManyRandSOS", "_test___envelopes_8cpp.html#acb1013aa3bc96395b2f2226918824b84", null ],
    [ "runTests", "_test___envelopes_8cpp.html#a5dcb537699bebb9e9db36ab19c5aacf7", null ]
];