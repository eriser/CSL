var _ambisonic_utilities_8h =
[
    [ "AmbisonicMixer", "classcsl_1_1_ambisonic_mixer.html", "classcsl_1_1_ambisonic_mixer" ],
    [ "AmbisonicRotator", "classcsl_1_1_ambisonic_rotator.html", "classcsl_1_1_ambisonic_rotator" ],
    [ "AMBI_INVSQRT2", "_ambisonic_utilities_8h.html#a6870016f528b125eb0b29b05c93f0560", null ],
    [ "Axes", "_ambisonic_utilities_8h.html#a5ce0ce604e0e0d6fb264300837887d43", [
      [ "kTILT", "_ambisonic_utilities_8h.html#a5ce0ce604e0e0d6fb264300837887d43a52e6387936ce0d8a295aefd3c441625f", null ],
      [ "kTUMBLE", "_ambisonic_utilities_8h.html#a5ce0ce604e0e0d6fb264300837887d43ab4465c2ffbdf140c239b5b1c805b30d0", null ],
      [ "kROTATE", "_ambisonic_utilities_8h.html#a5ce0ce604e0e0d6fb264300837887d43af033bc6f7518455844e0f08624cedbe1", null ]
    ] ],
    [ "singularValueDecomposition", "_ambisonic_utilities_8h.html#a9e59f270c22b987a5b06484abc53b98f", null ],
    [ "fumaEncodingWeights", "_ambisonic_utilities_8h.html#a00d2bb3af40df0438f5af4f06cde1f26", null ],
    [ "fumaIndexedEncodingWeights", "_ambisonic_utilities_8h.html#a260525bb28882f9122be05f080ae141f", null ]
];