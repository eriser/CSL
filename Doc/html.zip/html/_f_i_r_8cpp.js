var _f_i_r_8cpp =
[
    [ "BANDPASS", "_f_i_r_8cpp.html#a3ebfa4d7e384f53e6a37ff0d0d98627d", null ],
    [ "DIFFERENTIATOR", "_f_i_r_8cpp.html#a677e6c6816bcf472eaf8875cc8fe729d", null ],
    [ "HILBERT", "_f_i_r_8cpp.html#aff6936b3d5de51dd8968ce8a44c0176d", null ],
    [ "NEGATIVE", "_f_i_r_8cpp.html#ae8da539b402ed6856028a0a60240bbff", null ],
    [ "POSITIVE", "_f_i_r_8cpp.html#aefb7723e1092c450754ef6c07922b1bf", null ],
    [ "Pi", "_f_i_r_8cpp.html#a0c233fcb94ea9f05596b48427095806e", null ],
    [ "Pi2", "_f_i_r_8cpp.html#aa5f7ec8ff2ff24995c32143fc53005da", null ],
    [ "GRIDDENSITY", "_f_i_r_8cpp.html#a701053a83ca85d18c7e72066e97eca2e", null ],
    [ "MAXITERATIONS", "_f_i_r_8cpp.html#a988e935ee6ed10d959e44e47780ddcbf", null ],
    [ "remez", "_f_i_r_8cpp.html#a3fc5d3fe605c3a0eba5ad6b50551b137", null ],
    [ "CreateDenseGrid", "_f_i_r_8cpp.html#ab178ceca48eb9f872535826a39da0c33", null ],
    [ "InitialGuess", "_f_i_r_8cpp.html#afd685c1c622c866839786c26b661593f", null ],
    [ "CalcParms", "_f_i_r_8cpp.html#a4261c87ad066aa678779da17d1c61175", null ],
    [ "ComputeA", "_f_i_r_8cpp.html#a0e52751f94d4c3f2e5ade81d059235ae", null ],
    [ "CalcError", "_f_i_r_8cpp.html#ab83c6934bd5df22f85e2d1eed5cad889", null ],
    [ "Search", "_f_i_r_8cpp.html#aad92c31fd79d2efc81710a72b84f1e8b", null ],
    [ "FreqSample", "_f_i_r_8cpp.html#a21508975da3e2e735654f6c6eeb4a038", null ],
    [ "isDone", "_f_i_r_8cpp.html#ab7e8a38d60f09445a731d9f9fe763a39", null ]
];