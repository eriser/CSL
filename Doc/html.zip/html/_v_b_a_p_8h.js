var _v_b_a_p_8h =
[
    [ "VBAP", "classcsl_1_1_v_b_a_p.html", "classcsl_1_1_v_b_a_p" ],
    [ "StereoPanner", "classcsl_1_1_stereo_panner.html", "classcsl_1_1_stereo_panner" ],
    [ "SurroundPanner", "classcsl_1_1_surround_panner.html", "classcsl_1_1_surround_panner" ],
    [ "VBAPSourceCache", "classcsl_1_1_v_b_a_p_source_cache.html", "classcsl_1_1_v_b_a_p_source_cache" ],
    [ "SpeakerSet", "classcsl_1_1_speaker_set.html", "classcsl_1_1_speaker_set" ],
    [ "SpeakerSetLayout", "classcsl_1_1_speaker_set_layout.html", "classcsl_1_1_speaker_set_layout" ],
    [ "MAX_NUM_VBAP_SOURCES", "_v_b_a_p_8h.html#ad71cc257c5758af01a507daffe10cd0a", null ],
    [ "_NO_EXCEPTION", "_v_b_a_p_8h.html#ab9f2466893d703a4efe52b507c2c17b1", null ],
    [ "STD", "_v_b_a_p_8h.html#ac8013bd40e966bc6ba364e0f6ff7acb7", null ],
    [ "TRYBEGIN", "_v_b_a_p_8h.html#a5ec6d8002507de81f8691b3058795737", null ],
    [ "CATCHERROR", "_v_b_a_p_8h.html#a3626d5230d5bd2e6172a52c8dd5ac007", null ],
    [ "deg2rad", "_v_b_a_p_8h.html#a0578fc1dd44e655837453fde19c6b46f", null ],
    [ "CSLMatrix", "_v_b_a_p_8h.html#aece1353e137d913aaa22a8575686d605", null ],
    [ "VBAPMode", "_v_b_a_p_8h.html#ad50dc2adb06a7b131f98c7eaaaa826ca", [
      [ "kAuto", "_v_b_a_p_8h.html#ad50dc2adb06a7b131f98c7eaaaa826caa8c4ffd482a273f50e1441701629f611d", null ],
      [ "kPantophonic", "_v_b_a_p_8h.html#ad50dc2adb06a7b131f98c7eaaaa826caad3cf179975d2c99b10e7eb196c356861", null ],
      [ "kPeriphonic", "_v_b_a_p_8h.html#ad50dc2adb06a7b131f98c7eaaaa826caa14b6888a26727f38ef86bfed23c46b03", null ]
    ] ]
];