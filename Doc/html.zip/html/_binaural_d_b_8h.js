var _binaural_d_b_8h =
[
    [ "HRTF", "classcsl_1_1_h_r_t_f.html", "classcsl_1_1_h_r_t_f" ],
    [ "HRTFDatabase", "classcsl_1_1_h_r_t_f_database.html", "classcsl_1_1_h_r_t_f_database" ],
    [ "HRTF_BLOCK_SIZE", "_binaural_d_b_8h.html#a0b8c53920d9c4c1f8006788a3e93900c", null ],
    [ "HRIR_SIZE", "_binaural_d_b_8h.html#a94982d0b55e2831241e74a734703af48", null ],
    [ "FLIST_NAME", "_binaural_d_b_8h.html#a8a1da7dda7be7617938c822544c20635", null ],
    [ "DEFAULT_HRTF_FOLDER", "_binaural_d_b_8h.html#ac807b24fa93a4fa7e02b5e40f86a0c3c", null ],
    [ "HRTF_RESOURCE", "_binaural_d_b_8h.html#a385893ba27d4739ecbac6bdfca107cb7", null ],
    [ "cmac", "_binaural_d_b_8h.html#a66ef1a40b93e9a9baac1526bfcc310c5", null ],
    [ "HRTFVector", "_binaural_d_b_8h.html#a59b02713a67587b4f6682884d994f0bd", null ]
];