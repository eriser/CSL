var class_p_m_e =
[
    [ "PME", "class_p_m_e.html#a1a963c7479060abe2fac536f94bc60c0", null ],
    [ "PME", "class_p_m_e.html#ad488ab3dcc831dc86f88f25078ab6bba", null ],
    [ "~PME", "class_p_m_e.html#a3ff0d2990f8071444591f1d3af2d2867", null ],
    [ "update_grabbed_position", "class_p_m_e.html#aebc4fb369b9f2ffc48afa3c3e2e0df4a", null ],
    [ "check_for_grabbed_source", "class_p_m_e.html#a5f95f7a0ae2bad47943dbe20ce62a03c", null ],
    [ "add_pme_source", "class_p_m_e.html#abea1995cd5329661c376c2e9fbe04d8f", null ],
    [ "remove_all_sources", "class_p_m_e.html#a98b752a41adc92379a57966539901d0f", null ],
    [ "manage_sources", "class_p_m_e.html#aa3306abdd6206a5f5879761777df48a4", null ],
    [ "set_remote_addr_and_port", "class_p_m_e.html#a9e17d0c13821fddbba5dedbc83cec80f", null ],
    [ "management_func", "class_p_m_e.html#a627434ab2d942ce40a0e1c8e44e150e6", null ],
    [ "start_management_thread", "class_p_m_e.html#a63c0e7b0bcc90c141322b4f4d5f1a8b8", null ],
    [ "stop_management_thread", "class_p_m_e.html#a77cd5fb6f45451d99c6c7b66537e5fa9", null ],
    [ "management_thread", "class_p_m_e.html#a291e79a25053151dc601d056589afab9", null ],
    [ "controller", "class_p_m_e.html#acb5cff4ef22e06202737caef4c50e6d9", null ],
    [ "pme_source_list", "class_p_m_e.html#a0a82833c20de10e0140226d5aa5db930", null ],
    [ "grabbed_source", "class_p_m_e.html#af5ba16ccf19bf56ddf86457581cd3187", null ],
    [ "num_sources", "class_p_m_e.html#a147fa404d11f8e59b346ba8e60f60544", null ],
    [ "keep_processing_sources", "class_p_m_e.html#a4fd29ac373c465bb978ab252c464169e", null ]
];