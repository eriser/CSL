var _envelope_8h =
[
    [ "LineSegment", "classcsl_1_1_line_segment.html", "classcsl_1_1_line_segment" ],
    [ "Envelope", "classcsl_1_1_envelope.html", "classcsl_1_1_envelope" ],
    [ "ADSR", "classcsl_1_1_a_d_s_r.html", "classcsl_1_1_a_d_s_r" ],
    [ "AR", "classcsl_1_1_a_r.html", "classcsl_1_1_a_r" ],
    [ "Triangle", "classcsl_1_1_triangle.html", "classcsl_1_1_triangle" ],
    [ "RandEnvelope", "classcsl_1_1_rand_envelope.html", "classcsl_1_1_rand_envelope" ],
    [ "kLine", "_envelope_8h.html#a826ad4ff06c3033bc454cff54e00e0de", null ],
    [ "kExpon", "_envelope_8h.html#a26bcb495bc716cdb7358fd46fdfdcfa4", null ],
    [ "LineMode", "_envelope_8h.html#a294f8957c5dffb900bef7d2971ff08d3", null ],
    [ "Breakpoints", "_envelope_8h.html#ace598ff3e15a3bb28bffb5fa69479579", null ]
];