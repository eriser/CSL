var _clipper_8h =
[
    [ "Clipper", "classcsl_1_1_clipper.html", "classcsl_1_1_clipper" ],
    [ "ClipperFlags", "_clipper_8h.html#a86daae45e8e75cc60983b1e464a3bbc1", [
      [ "kMin", "_clipper_8h.html#a86daae45e8e75cc60983b1e464a3bbc1a815c66dd62c5cd9ee2952ad7f24a6f50", null ],
      [ "kMax", "_clipper_8h.html#a86daae45e8e75cc60983b1e464a3bbc1a75550571e5400544a7e4494f69083879", null ],
      [ "kBoth", "_clipper_8h.html#a86daae45e8e75cc60983b1e464a3bbc1ac18cdd279f63c3c537c36ca6a68bea82", null ]
    ] ]
];