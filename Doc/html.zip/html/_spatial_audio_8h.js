var _spatial_audio_8h =
[
    [ "Spatializer", "classcsl_1_1_spatializer.html", "classcsl_1_1_spatializer" ],
    [ "Auralizer", "classcsl_1_1_auralizer.html", "classcsl_1_1_auralizer" ],
    [ "SpeakerLayoutExpert", "classcsl_1_1_speaker_layout_expert.html", "classcsl_1_1_speaker_layout_expert" ],
    [ "PannerType", "_spatial_audio_8h.html#abbcd4b0b66467bc98cd7b0e18f23721a", [
      [ "kAutomatic", "_spatial_audio_8h.html#abbcd4b0b66467bc98cd7b0e18f23721aa0bfab71fe931bc4c7bea13a30f46ec5a", null ],
      [ "kBinaural", "_spatial_audio_8h.html#abbcd4b0b66467bc98cd7b0e18f23721aa38104cdba75d64b1be6c5a6c6b2c42f3", null ],
      [ "kVBAP", "_spatial_audio_8h.html#abbcd4b0b66467bc98cd7b0e18f23721aa363ab9ea1f540283f46d7373fbd019bf", null ],
      [ "kAmbisonic", "_spatial_audio_8h.html#abbcd4b0b66467bc98cd7b0e18f23721aa990e3ee7269c4cf501549d78c57762ee", null ],
      [ "kSimple", "_spatial_audio_8h.html#abbcd4b0b66467bc98cd7b0e18f23721aa7348581b05aa7761b438c40b0d37a52a", null ],
      [ "kWFS", "_spatial_audio_8h.html#abbcd4b0b66467bc98cd7b0e18f23721aae159ec6f757691dd54b72869596aabbf", null ]
    ] ]
];