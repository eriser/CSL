var class_communicating_socket =
[
    [ "CommunicatingSocket", "class_communicating_socket.html#a0017517b8d6e761fde0c40475af3b2ab", null ],
    [ "CommunicatingSocket", "class_communicating_socket.html#a27d758db782b3be7d28741e92cb613d1", null ],
    [ "connect", "class_communicating_socket.html#a9192374d9baab8e189860aa8d913683c", null ],
    [ "send", "class_communicating_socket.html#aca4e86085c064641e86ae24ea29bbb94", null ],
    [ "recv", "class_communicating_socket.html#a7cf1fd470c0060171b68df9f68c7bd01", null ],
    [ "getForeignAddress", "class_communicating_socket.html#a13f9eca30ef56836cf23c163c848c09e", null ],
    [ "getForeignPort", "class_communicating_socket.html#a184fbb4775184b87ebd886a5587eb1a3", null ],
    [ "getLocalAddress", "class_communicating_socket.html#a0fca07bdfa97874fba1a17995ed7cda3", null ],
    [ "getLocalPort", "class_communicating_socket.html#ae01143b667d69483a2f53d0f4ce7eeed", null ],
    [ "setLocalPort", "class_communicating_socket.html#a773fe4a35146002de76952e16fdebcfa", null ],
    [ "setLocalAddressAndPort", "class_communicating_socket.html#aa6b986410bc2e606ba27d01fa7cb8836", null ],
    [ "cleanUp", "class_communicating_socket.html#ac5060aeb501044044351d5a85b3fc95f", null ],
    [ "resolveService", "class_communicating_socket.html#a982c63b25c5b756321a74074a275adbc", null ],
    [ "sockDesc", "class_communicating_socket.html#ad5704d2fdfb062139e1f88831617bbfb", null ]
];