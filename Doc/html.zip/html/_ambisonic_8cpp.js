var _ambisonic_8cpp =
[
    [ "AMBI_INVSQRT2", "_ambisonic_8cpp.html#a6870016f528b125eb0b29b05c93f0560", null ],
    [ "INV_SQRT2", "_ambisonic_8cpp.html#a9eb2cd7213f88b3f5f50c1e5642ffdf1", null ],
    [ "AMBI_INVSQRT2", "_ambisonic_8cpp.html#a6870016f528b125eb0b29b05c93f0560", null ]
];