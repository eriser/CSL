var _c_s_l___exceptions_8h =
[
    [ "CException", "classcsl_1_1_c_exception.html", "classcsl_1_1_c_exception" ],
    [ "MemoryError", "classcsl_1_1_memory_error.html", "classcsl_1_1_memory_error" ],
    [ "ValueError", "classcsl_1_1_value_error.html", "classcsl_1_1_value_error" ],
    [ "TimingError", "classcsl_1_1_timing_error.html", "classcsl_1_1_timing_error" ],
    [ "RunTimeError", "classcsl_1_1_run_time_error.html", "classcsl_1_1_run_time_error" ],
    [ "LogicError", "classcsl_1_1_logic_error.html", "classcsl_1_1_logic_error" ],
    [ "DomainError", "classcsl_1_1_domain_error.html", "classcsl_1_1_domain_error" ],
    [ "OutOfRangeError", "classcsl_1_1_out_of_range_error.html", "classcsl_1_1_out_of_range_error" ],
    [ "IOError", "classcsl_1_1_i_o_error.html", "classcsl_1_1_i_o_error" ],
    [ "DBError", "classcsl_1_1_d_b_error.html", "classcsl_1_1_d_b_error" ],
    [ "ProcessingError", "classcsl_1_1_processing_error.html", "classcsl_1_1_processing_error" ],
    [ "Status", "_c_s_l___exceptions_8h.html#ac2c2565225bd914df34848bfcc5517f6", [
      [ "kOk", "_c_s_l___exceptions_8h.html#ac2c2565225bd914df34848bfcc5517f6aaa59f61470af66f345ad160987eca8c2", null ],
      [ "kFound", "_c_s_l___exceptions_8h.html#ac2c2565225bd914df34848bfcc5517f6acdfcb4f9849df5e2ba299bd6b421d97d", null ],
      [ "kNotFound", "_c_s_l___exceptions_8h.html#ac2c2565225bd914df34848bfcc5517f6aa0c74ff9c94bab40439704ccd052b36f", null ],
      [ "kEmpty", "_c_s_l___exceptions_8h.html#ac2c2565225bd914df34848bfcc5517f6ab4f9930c15fdd9b011104f62759ea36d", null ],
      [ "kErr", "_c_s_l___exceptions_8h.html#ac2c2565225bd914df34848bfcc5517f6a452950010f4a2bea6156404e12a824d3", null ]
    ] ]
];