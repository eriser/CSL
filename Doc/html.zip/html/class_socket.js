var class_socket =
[
    [ "~Socket", "class_socket.html#aeac4eb6379a543d38ed88977d3b6630a", null ],
    [ "Socket", "class_socket.html#a656389d58fa00729ff70c4e159623f5c", null ],
    [ "Socket", "class_socket.html#a53e00027bab2125a2b407914c6148589", null ],
    [ "Socket", "class_socket.html#a6a2609eef6559336a595a336f138d395", null ],
    [ "getLocalAddress", "class_socket.html#a0fca07bdfa97874fba1a17995ed7cda3", null ],
    [ "getLocalPort", "class_socket.html#ae01143b667d69483a2f53d0f4ce7eeed", null ],
    [ "setLocalPort", "class_socket.html#a773fe4a35146002de76952e16fdebcfa", null ],
    [ "setLocalAddressAndPort", "class_socket.html#aa6b986410bc2e606ba27d01fa7cb8836", null ],
    [ "cleanUp", "class_socket.html#ac5060aeb501044044351d5a85b3fc95f", null ],
    [ "resolveService", "class_socket.html#a982c63b25c5b756321a74074a275adbc", null ],
    [ "operator=", "class_socket.html#a1ef8f4c222c32756c8b1537323702df8", null ],
    [ "sockDesc", "class_socket.html#ad5704d2fdfb062139e1f88831617bbfb", null ]
];