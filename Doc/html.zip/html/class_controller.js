var class_controller =
[
    [ "Controller", "class_controller.html#a48c4a2f33621df3657862211eb9c5e27", null ],
    [ "Controller", "class_controller.html#a95c56822d667e94b031451729ce069a9", null ],
    [ "~Controller", "class_controller.html#a0ab87934c4f7a266cfdb86e0f36bc1b5", null ],
    [ "set_remote_addr_and_port", "class_controller.html#a202cb85241ee303baf1970e632b76405", null ],
    [ "set_data", "class_controller.html#ac82c5f6c1b508a72ade5afd4d8b74edc", null ],
    [ "get_data", "class_controller.html#ab9b02e8fa0e35f18fbd4648cd5b2cbab", null ],
    [ "get_position", "class_controller.html#a07f3d56a136951098fc7f35ff5e7b84e", null ],
    [ "remote_read_func", "class_controller.html#ae645e4a09f76f8c8e752f7d2d2c602f5", null ],
    [ "start_reader_thread", "class_controller.html#a059ea02eb3864260d5dd6123b20c48be", null ],
    [ "get_remote_data", "class_controller.html#a60726fdfdaac83b9dfb454591bce42f9", null ],
    [ "_position", "class_controller.html#a149ede6996e40156f568649d1a41726f", null ],
    [ "_velocity", "class_controller.html#a07349785d8ac64218a54b2a143133ed3", null ],
    [ "glove_state", "class_controller.html#a8c6ee2cb5e85d23dc179a50ab316a0af", null ],
    [ "sync", "class_controller.html#a9adee94a7b606fd84ea61fbb306b2fa2", null ],
    [ "thread", "class_controller.html#a35aac886f1fd617b318837bd3320873c", null ],
    [ "foreign_port", "class_controller.html#a055a13ae7c29104a8d05b95f2414c2f3", null ],
    [ "foreign_net_address", "class_controller.html#a817b7bd89ffe4f933d818ebd467bde73", null ],
    [ "sock", "class_controller.html#a731d22f887d2d8d9fc5420ad09eed2a1", null ]
];