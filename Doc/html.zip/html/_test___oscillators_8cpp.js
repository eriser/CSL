var _test___oscillators_8cpp =
[
    [ "USE_TEST_MAIN", "_test___oscillators_8cpp.html#a8cb66fa186ca4331bbdb9c15a8c89117", null ],
    [ "TABLE_SIZE", "_test___oscillators_8cpp.html#a032503e76d6f69bc67e99e909c8125da", null ],
    [ "testSweep", "_test___oscillators_8cpp.html#aacf61b81fdb0357f8db807d0c2b3bfa9", null ],
    [ "testSimpleSines", "_test___oscillators_8cpp.html#a0f75f194bf70083fe3b794a076f3c4c1", null ],
    [ "testBasicWaves", "_test___oscillators_8cpp.html#a6398d4e6f9edda00e6ec01ca077473c3", null ],
    [ "testScaledSin", "_test___oscillators_8cpp.html#a9404b24355bb397a1dd93ec944227da4", null ],
    [ "testWavetableInterpolation", "_test___oscillators_8cpp.html#a2666c8f3263eaa57fd0a4e66e9979326", null ],
    [ "testAMFMSin", "_test___oscillators_8cpp.html#aa191c56a16d70327670997305c29d229", null ],
    [ "dumpAMFMSin", "_test___oscillators_8cpp.html#a056ec2f62c5d581fcb25a50ccdd042f9", null ],
    [ "testSumOfSinesCached", "_test___oscillators_8cpp.html#a0d4fee0b749e38c02827159ae6eba21d", null ],
    [ "testSumOfSines1F", "_test___oscillators_8cpp.html#afce1168f6bff4c61003d580761144b3b", null ],
    [ "testSumOfSinesSteps", "_test___oscillators_8cpp.html#a6a1dd927f2d6ce731b34385b0b9dba8e", null ],
    [ "testSumOfSinesNonCached", "_test___oscillators_8cpp.html#af72dabba33cc043d8c55079972d41fc7", null ],
    [ "testWaveTableFromFile", "_test___oscillators_8cpp.html#a78730da4bb7f0c2d042de5c5b8acb55f", null ],
    [ "test_SHARC", "_test___oscillators_8cpp.html#a59bd65676fab0cce8b1720dc197d965e", null ],
    [ "test_SHARC2", "_test___oscillators_8cpp.html#abc81ef3765e2a05e96560e1082b47210", null ],
    [ "runTests", "_test___oscillators_8cpp.html#a5dcb537699bebb9e9db36ab19c5aacf7", null ]
];