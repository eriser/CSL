var _binaural_8h =
[
    [ "BinauralPanner", "classcsl_1_1_binaural_panner.html", "classcsl_1_1_binaural_panner" ],
    [ "BinauralSourceCache", "classcsl_1_1_binaural_source_cache.html", "classcsl_1_1_binaural_source_cache" ],
    [ "SUM_DOWNS", "_binaural_8h.html#a185dc3f5f2b5a2b97399cca304465606", null ],
    [ "FFT_DOWNS", "_binaural_8h.html#a58c8e9896e7394f5ace7dbc41f2fda93", null ],
    [ "LEN_DOWNS", "_binaural_8h.html#a10e9477c1af6e0474740553213e3c6ef", null ]
];