var class_f_f_t_real =
[
    [ "BitReversedLUT", "class_f_f_t_real_1_1_bit_reversed_l_u_t.html", "class_f_f_t_real_1_1_bit_reversed_l_u_t" ],
    [ "TrigoLUT", "class_f_f_t_real_1_1_trigo_l_u_t.html", "class_f_f_t_real_1_1_trigo_l_u_t" ],
    [ "flt_t", "class_f_f_t_real.html#ada31be985e426271d81f373603272b11", null ],
    [ "FFTReal", "class_f_f_t_real.html#ac98f9b768dc122c212b6f6e4ce878e18", null ],
    [ "~FFTReal", "class_f_f_t_real.html#a28ef7dceefba4ab73b3fecdb68a56334", null ],
    [ "FFTReal", "class_f_f_t_real.html#a1ebad9c5cbe255ff47e1e16cfa3184bd", null ],
    [ "do_fft", "class_f_f_t_real.html#aaef06fd9a9f9e070c5a64b8c4191c1b7", null ],
    [ "do_ifft", "class_f_f_t_real.html#a8a09a4f467150be6714a2895654e9c83", null ],
    [ "rescale", "class_f_f_t_real.html#abf221c16cff2a4787765f4258c567a3a", null ],
    [ "operator=", "class_f_f_t_real.html#ae8c414cfa8cbf2e767d7d5da83aadd45", null ],
    [ "operator==", "class_f_f_t_real.html#ae353aed8b2ca1e3779a616309ac836c2", null ],
    [ "operator!=", "class_f_f_t_real.html#aa6cb1a262290d52713382e5ce40498b2", null ],
    [ "_bit_rev_lut", "class_f_f_t_real.html#ab24e686a3b807eb9c186a5c8d62af332", null ],
    [ "_trigo_lut", "class_f_f_t_real.html#a83dbf5146fee4411bc9640cd2add6967", null ],
    [ "_sqrt2_2", "class_f_f_t_real.html#aa04dbad4863a20847b0d532e2cbf812e", null ],
    [ "_length", "class_f_f_t_real.html#a10fa025196fafd071a86f536872a9618", null ],
    [ "_nbr_bits", "class_f_f_t_real.html#a95eaee60efb0bea37854bb14782948ff", null ],
    [ "_buffer_ptr", "class_f_f_t_real.html#a5ba67ad51433f3cc971f9471ac49b3ad", null ]
];