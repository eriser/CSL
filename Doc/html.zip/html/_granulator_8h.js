var _granulator_8h =
[
    [ "Grain", "structcsl_1_1_grain.html", "structcsl_1_1_grain" ],
    [ "GrainCloud", "classcsl_1_1_grain_cloud.html", "classcsl_1_1_grain_cloud" ],
    [ "GrainPlayer", "classcsl_1_1_grain_player.html", "classcsl_1_1_grain_player" ],
    [ "MAXGRAINS", "_granulator_8h.html#ac7adab629601e2f0e1229733a4fd9f52", null ],
    [ "Grain", "_granulator_8h.html#aee1aed7f4066712c295e6dec02d63f37", null ],
    [ "GrainulatorState", "_granulator_8h.html#ab018a0dfbf920a92b094024e343148ee", [
      [ "kFree", "_granulator_8h.html#ab018a0dfbf920a92b094024e343148eea39e0c80c5e589948a357728ae1dcc7e4", null ],
      [ "kDSP", "_granulator_8h.html#ab018a0dfbf920a92b094024e343148eeaaf65302c79ca10b7f1d5c47e4fa3f8de", null ],
      [ "kSched", "_granulator_8h.html#ab018a0dfbf920a92b094024e343148eead2250533567535a6b602532579006190", null ]
    ] ]
];