var _test___effects_8cpp =
[
    [ "SAFliter", "class_s_a_fliter.html", "class_s_a_fliter" ],
    [ "USE_TEST_MAIN", "_test___effects_8cpp.html#a8cb66fa186ca4331bbdb9c15a8c89117", null ],
    [ "testClipper", "_test___effects_8cpp.html#ae9625d0c21795776463d1a2b914f91a5", null ],
    [ "testFIR", "_test___effects_8cpp.html#a20d6fccf755147b04e91512f65560082", null ],
    [ "testFilters", "_test___effects_8cpp.html#a375e7fc1105127f231e979b427de698d", null ],
    [ "testDynamicFilters", "_test___effects_8cpp.html#a4af66905fdf94634718216fe8a9d70e3", null ],
    [ "testDynamicVoice", "_test___effects_8cpp.html#a76face6367bd43eb454aa4c20a27c183", null ],
    [ "testNDynamicFilters", "_test___effects_8cpp.html#abbba29c216ee85d270c07ed6d8f71c77", null ],
    [ "testReverb", "_test___effects_8cpp.html#a089a840b0962b0d9b7f7ffd7f1537420", null ],
    [ "testStereoverb", "_test___effects_8cpp.html#a23dc9b37c4ee0cab793972382af9aef2", null ],
    [ "testMultiTap", "_test___effects_8cpp.html#ab25d4b3154b179ef79aea86f5df9d1f0", null ],
    [ "testBlockUpsizer", "_test___effects_8cpp.html#a1744e34ab6f7e8658670470d68a5defe", null ],
    [ "testBlockDownsizer", "_test___effects_8cpp.html#a1c610a2061cac93164b2c1643e40b153", null ],
    [ "testSplitJoin1", "_test___effects_8cpp.html#ac7993b6e49130b9289be02563c68f52b", null ],
    [ "testSplitJoin2", "_test___effects_8cpp.html#a9b0145f4b21bad882f0e4da1293a64c8", null ],
    [ "testFanMix1", "_test___effects_8cpp.html#af5ccb0ad8d03385113132aee32407f5f", null ],
    [ "testFanMix2", "_test___effects_8cpp.html#aab8c2101173734e32288769e283cbfcf", null ],
    [ "createRandFreqEnvPatch", "_test___effects_8cpp.html#ace4c6f1b503dccf443c2dc63cb708ac5", null ],
    [ "testDynamicMixer", "_test___effects_8cpp.html#a4c0ddfe6849232ee99ac12cebb07df85", null ],
    [ "testSAFilter", "_test___effects_8cpp.html#ad1c2e7af742c3aeb268e2028f5e8b76c", null ],
    [ "runTests", "_test___effects_8cpp.html#a5dcb537699bebb9e9db36ab19c5aacf7", null ]
];