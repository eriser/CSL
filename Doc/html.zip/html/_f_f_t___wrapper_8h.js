var _f_f_t___wrapper_8h =
[
    [ "Abst_FFT_W", "classcsl_1_1_abst___f_f_t___w.html", "classcsl_1_1_abst___f_f_t___w" ],
    [ "CSL_FFTType", "_f_f_t___wrapper_8h.html#a43b6ef5ac5ebbd89646ca593e5aaa09d", [
      [ "CSL_FFT_REAL", "_f_f_t___wrapper_8h.html#a43b6ef5ac5ebbd89646ca593e5aaa09da9fb5e4c03ca33f7d76364d3417d99e44", null ],
      [ "CSL_FFT_COMPLEX", "_f_f_t___wrapper_8h.html#a43b6ef5ac5ebbd89646ca593e5aaa09da33b5a91793f688bc749245ae4b52003f", null ],
      [ "CSL_FFT_MAGPHASE", "_f_f_t___wrapper_8h.html#a43b6ef5ac5ebbd89646ca593e5aaa09da31c1c89ad2b88859a804bd951a3e8dc4", null ]
    ] ],
    [ "CSL_FFTDir", "_f_f_t___wrapper_8h.html#a6c0450b399878c57afc7365708142057", [
      [ "CSL_FFT_FORWARD", "_f_f_t___wrapper_8h.html#a6c0450b399878c57afc7365708142057a04d5da509aa8f06a95d91089f8bd2c39", null ],
      [ "CSL_FFT_INVERSE", "_f_f_t___wrapper_8h.html#a6c0450b399878c57afc7365708142057a970063c67256c8f89dbfd1938685bd69", null ]
    ] ]
];