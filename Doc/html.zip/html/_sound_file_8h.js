var _sound_file_8h =
[
    [ "SoundFileMetadata", "classcsl_1_1_sound_file_metadata.html", "classcsl_1_1_sound_file_metadata" ],
    [ "Abst_SoundFile", "classcsl_1_1_abst___sound_file.html", "classcsl_1_1_abst___sound_file" ],
    [ "SoundCue", "classcsl_1_1_sound_cue.html", "classcsl_1_1_sound_cue" ],
    [ "kSoundFileRead", "_sound_file_8h.html#ae5b703425101be375c8cfb4e8e66d312", null ],
    [ "kSoundFileWrite", "_sound_file_8h.html#a42adc602d9c6bcc806c278407e0714e2", null ],
    [ "kSoundFileReadWrite", "_sound_file_8h.html#aa6620551f68c7ee53d37431152dbb501", null ],
    [ "kSoundFileFormatWAV", "_sound_file_8h.html#ae7c06dae59fb80995fe10d2da6dcfef8", null ],
    [ "kSoundFileFormatAIFF", "_sound_file_8h.html#adc78c02d6bf803353458046fbe0d119f", null ],
    [ "kSoundFileFormatSND", "_sound_file_8h.html#a83be1484173db5c2682a0027c8c3c78c", null ],
    [ "kSoundFileFormatEBICSF", "_sound_file_8h.html#af388bf51b2a71e19a987d3b3efa6ccdf", null ],
    [ "kSoundFileFormatRaw", "_sound_file_8h.html#a2d88cb1e5b7d9c0d4a9a5a57b713965a", null ],
    [ "kSoundFileFormatOther", "_sound_file_8h.html#a01690ec9c6cfefe80529014d5365d138", null ],
    [ "SoundFileMode", "_sound_file_8h.html#a4ade6957da2b012211453bd36eecf3e2", null ],
    [ "SoundFileFormat", "_sound_file_8h.html#a2022a31a2ae858ba627d79ee25c8355d", null ]
];