var _sound_file_c_a_8cpp =
[
    [ "CONVERT_16_BIT", "_sound_file_c_a_8cpp.html#a05362f3add64a4c08e218b77bf6caedf", null ],
    [ "CONVERT_24_BIT", "_sound_file_c_a_8cpp.html#a80f70df8629a3b0e87c5ba4120e60a8c", null ],
    [ "int8", "_sound_file_c_a_8cpp.html#a1b956fe1df85f3c132b21edb4e116458", null ],
    [ "uint8", "_sound_file_c_a_8cpp.html#adde6aaee8457bee49c2a92621fe22b79", null ],
    [ "int16", "_sound_file_c_a_8cpp.html#a259fa4834387bd68627ddf37bb3ebdb9", null ],
    [ "uint16", "_sound_file_c_a_8cpp.html#a05f6b0ae8f6a6e135b0e290c25fe0e4e", null ],
    [ "int32", "_sound_file_c_a_8cpp.html#a43d43196463bde49cb067f5c20ab8481", null ],
    [ "uint32", "_sound_file_c_a_8cpp.html#a1134b580f8da4de94ca6b1de4d37975e", null ]
];