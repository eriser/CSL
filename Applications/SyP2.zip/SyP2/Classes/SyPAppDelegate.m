//
//  SyPAppDelegate.m
//  SyP
//
//  Created by Adam Hoyle on 28/09/2009.
//  Copyright Do-Tank 2009. All rights reserved.
//

#import "SyPAppDelegate.h"
#import "SyPViewController.h"

@implementation SyPAppDelegate

@synthesize window;
@synthesize viewController;
@synthesize menuController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
	_gameLevel = 0;
	
	model = [[DataModel alloc] init];
	[model startPreparingModel];
	
	menuController = [[MainMenuViewController alloc] init];
	[window addSubview:menuController.view];  
	
    // Override point for customization after app launch    
    //[window addSubview:viewController.view];
    [window makeKeyAndVisible];
}

- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}

- (GameLevel *) getCurrentGameLevel
{
	return [model getLevel:_gameLevel];
}

- (NSInteger) levelCount
{
	return [model levelCount];
}

- (NSString *) nameForLevel:(NSInteger)intg
{
	return [model nameForLevel:intg];
}

- (void) chooseLevel:(NSInteger) intgr
{
	_gameLevel = intgr;
	if ([menuController.view superview]){
		[menuController.view removeFromSuperview];
	}
	[window addSubview:viewController.view];
	[viewController birthGameLevel:nil];
}

- (void) finishedLevel:(NSString *) reason
{
	if ([reason isEqual:@"exit"]){
		// user escaped!
	}
	
	if ([viewController.view superview]){
		[viewController cleanup]; // cleanup should clear csl
		[viewController.view removeFromSuperview];
	}
	[window addSubview:menuController.view];
}

@end
