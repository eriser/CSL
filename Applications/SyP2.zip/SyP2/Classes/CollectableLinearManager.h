//
//  CollectableLinearManager.h
//  SyP
//
//  Created by Adam Hoyle on 18/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GameLevel.h"
#import "CslSpatialisedSound.h"

@interface CollectableLinearManager : NSObject {
	CGPoint location;
	
	GameLevel *gameLevel;
	CslSpatialisedSound *cslSnd;
	
	int collectableCounter;
	NSString *collectableType;
	NSString *outroSound;
	
	BOOL isActive;
	
	BOOL isPlayerAlreadyFacingCollectable;
}

- (id) initWithGameLevel:(GameLevel *)gLevel andSpatialisedSound:(CslSpatialisedSound *)snd;
- (void) nextCollectable;
- (NSDictionary *) playerPositionHasChanged:(CGPoint)loc andAngle:(CGFloat)angle;
- (CGPoint) location;

@end
