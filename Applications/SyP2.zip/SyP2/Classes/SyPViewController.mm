//
//  SyPViewController.m
//  SyP
//
//  Created by Adam Hoyle on 28/09/2009.
//  Copyright Do-Tank 2009. All rights reserved.
//

#import "SyPViewController.h"
#import "SypGameViewCPWipe.h"
#import "FloorSpaceData.h"
#import <Foundation/Foundation.h>
#import "SyPAppDelegate.h"
#import "CollectableLinearManager.h"
#import "MonsterNPC.h"

#define kenterFrameTimerInterval 60 // 0.2 = once every five seconds - 4 = every 250 ms
#define kPlayerRotationStep 45.0f*(M_PI/180.0f) // pi = 180 degrees
#define kIntroTimeInterval 9.0f // how long between starting the level and actually birthing everything

@implementation SyPViewController


@synthesize enterFrameTimer;
@synthesize isLeftFoot;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

#pragma mark UIKit calls

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	gameIsActive = NO;
	// @TODO - should this happen automatically when the view is loaded?
	//[self performSelector:@selector(birthGameLevel:) withObject:nil afterDelay:2.0f];
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void) cleanup {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	NSLog(@"[SypVC] viewDidUnload - (should be) killing threads");
	[self clearGameLevel];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	NSLog(@"[SyPVC] didRecieveMemoryWarning");
	// Release any cached data, images, etc that aren't in use.
}

- (void)dealloc {
    [super dealloc];
}


#pragma mark game logic

- (void) birthGameLevel:(id)param {
	
	gameIsActive = NO;
	
	SyPAppDelegate *appDel = (SyPAppDelegate *)[[UIApplication sharedApplication] delegate];
	GameLevel *gl = [appDel getCurrentGameLevel];
	
	gamePlayAreaSize = [gl getPlayAreaSize];
	
	//
	// setup the player positioning
	//
	playerAngle = [gl getPlayerStartAngle];
	playerMovement = 1.0f;
	playerPosition = [gl getPlayerStartPosition];
	NSLog(@"[SypVC] initial playerPosition is %0.0fx%0.0f",playerPosition.x,playerPosition.y);
	// playerVector is overridden by the call to rotatePlayerToFixedRotation at the end of this call
	playerVector = CGPointMake(0.0f, 0.0f); 
	isPlayerFacingCollectable = NO;
	runningThresholdBPM = [gl getPlayerRunBPM];
	trippingThresholdBPM = [gl getPlayerTripBPM];
	trippingTimePenalty = [gl getTripTimePenalty];
	tripSoundName = [[gl getTripSound] retain];
	NSLog(@"tripSoundName=%@",tripSoundName);
	
	
	//
	// create the floor surfaces
	//
	//surfaceData = [[NSMutableArray arrayWithCapacity:1] retain];
	surfaceData = [[gl getArrayOfFloorSpaceDatas] retain];
	
	//
	// CREATE/LOAD/RUN THE CSL APP HERE
	//	
	csl = [[CslSpatialisedManager alloc] init];
	[csl loadHRTF];		// load the CSL data
	
	[csl startCSL];		// start the CSL thread
	
	NSLog(@"birthGameLevel - started all the CSL Stuff");
	
	[NSThread sleepForTimeInterval: 1.5];
	
	
	NSLog(@"birthGameLevel - now making a sound");
	
	cslSounds = [[NSMutableArray arrayWithCapacity:1] retain];
	
	NSString *introSound = [gl getIntroSound];
	[csl playSoundWithName:introSound];
	
	// we have fixed the duration of the intro, so the game
	// proper starts after a fixed duration
	introTimer = [NSTimer scheduledTimerWithTimeInterval:kIntroTimeInterval 
												  target:self 
												selector:@selector(delayedBirthGameLevel:)
												userInfo:nil
												 repeats:NO];
	
	// create the HUD and add it to the view
	mapView = [[GameMapView alloc] initWithFrame:CGRectMake(0,0,gamePlayAreaSize.width*4,gamePlayAreaSize.height*4) andGameSize:gamePlayAreaSize];
	[mapView renderSurfaces:surfaceData];
	[mapView setUserInteractionEnabled:NO]; // turn off clicks
	[[self view] addSubview:mapView];
	[mapView setHidden:YES];
	// rotate the map 90deg
	[mapView setTransform:CGAffineTransformMakeRotation(M_PI/2)];
	
	walkTimes = [[NSMutableArray arrayWithCapacity:0] retain];
	/*
	NSLog(@"birthGameLevel - done everything else, now waiting a bit, then updating player position");
	[NSThread sleepForTimeInterval: 1.5];
	[self rotatePlayerToFixedRotation:playerAngle];
	 */
}

- (void) delayedBirthGameLevel:(id)param
{
	CslSpatialisedSound *cslSnd;
	SyPAppDelegate *appDel = (SyPAppDelegate *)[[UIApplication sharedApplication] delegate];
	GameLevel *gl = [appDel getCurrentGameLevel];
	
	// creating collectable (with csl sound for collectable)
	cslSnd = [csl newSpatialisedSound];
	
	[cslSnd createEmptyThread];
	[cslSounds addObject:cslSnd];
	
	//CollectablesNPC col = 
	collectables = [[CollectableLinearManager alloc] initWithGameLevel:gl andSpatialisedSound:cslSnd];
	
	
	NSDictionary *monsterDict;
	monsters = [[NSMutableArray arrayWithCapacity:0] retain];
	int max = [gl getTotalMonsters];
	for (size_t i=0; i<max; i++) {
		monsterDict = [gl getMonsterDict:i];
		if (monsterDict){
			
			cslSnd = [csl newSpatialisedSound];
			[cslSnd createEmptyThread];
			[cslSounds addObject:cslSnd];
			
			MonsterNPC *monster = [[MonsterNPC alloc] initWithSpatialisedSound:cslSnd andDictionary:monsterDict];
			[monster setDelegate:self];
			[monsters addObject:monster];
		}
	}
	
	
	NSString *bgSound = [gl getLevelBgSound];
	[csl playLoopingSoundWithName:bgSound];
	
	//NSString *musicSound = [gl getLevelBgMusic];
	//[csl playLoopingSoundWithName:musicSound];
	
	[NSThread sleepForTimeInterval: 1.5];
	
	gameIsActive = YES;
	playerCanMove = YES;
	
	[self rotatePlayerToFixedRotation:playerAngle];
	
	self.enterFrameTimer = [NSTimer scheduledTimerWithTimeInterval:1.0/kenterFrameTimerInterval 
														 target:self 
													   selector:@selector(onEnterFrame) 
													   userInfo:nil 
														repeats:YES
						 ];

}


- (void) clearGameLevel
{
	// remove the timer.
	if (self.enterFrameTimer){
		[self.enterFrameTimer invalidate];
		self.enterFrameTimer = nil;
	}
	
	[self stopCountdownTimer];
	
	if (monsters){
		// clear up all of the monsters!
	}
	
	// cleanup csl
	if (csl){
		[csl cleanup];
		[csl release];
	}
	
	// remove the map view
	if (mapView){
		[mapView removeFromSuperview];
		[mapView release];
		mapView = nil;
	}
	
	if (walkTimes){
		[walkTimes release];
		walkTimes = nil;
	}
	
	gameIsActive = NO;
}


- (void) onEnterFrame
{
	if (gameIsActive){
		
		// @TODO - only update collectables if the user has moved.
		if (playerHasMoved){
			playerHasMoved = NO; // turn off the flag
			// first update the COLLECTABLES
			NSDictionary *dict = [collectables playerPositionHasChanged:playerPosition andAngle:playerAngle]; // we should prolly get somekind of return from this.
			isPlayerFacingCollectable = [(NSNumber *)[dict objectForKey:@"facingCollectable"] boolValue];
			
			//NSLog(@"[SypVC updatedSpatialisedSounds] angle=%0.2f pos=%0.2fx%0.2f sounds.count=%i isPlayerFacingCollectable=%d",playerAngle,playerPosition.x,playerPosition.y,[cslSounds count],isPlayerFacingCollectable);
			
			BOOL ret = [(NSNumber *)[dict objectForKey:@"collected"] boolValue];
			if (ret){
				
				NSString *outroSound = [dict objectForKey:@"outroSound"];
				if (outroSound) {
					[csl playSoundWithName:outroSound];
				}
				NSString *collectedType = [dict objectForKey:@"type"];
				if (collectedType){
					if ([collectedType isEqual:@"exit"]) {
						// Excellent, we found the exit, so go back to the menu
						gameIsActive = NO;
						_gameEndMode = @"exit";
						UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Well Done" message:@"You found the exit! Hurrah!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"w00t", nil];
						[alertView show];
						[alertView release];
					}
					
				}
			} else {
				BOOL isFacing = [(NSNumber *)[dict objectForKey:@"newlyFacingCollectable"] boolValue];
				if (isFacing == YES){
					NSLog(@"[SypVC updatedSpatialisedSounds] playing 'newlyFacingCollectable' sound");
					// ok, let's play a ding of somekind.
					[csl playSoundWithName:@"L1_homing"];
					
				}
			}
			
			NSString *monsterAttackSound = @"";
			BOOL collidedWithMonster = NO;
			int monsterMax = [monsters count];
			// now update the MONSTERS
			for (size_t i=0; i<monsterMax; i++) {
				MonsterNPC *monstr = [monsters objectAtIndex:i];
				NSDictionary *dict = [monstr playerPositionHasChanged:playerPosition andAngle:playerAngle];
				BOOL t_collided = [[dict objectForKey:@"collided"] boolValue];
				monsterAttackSound = [dict objectForKey:@"attackSound"];
				if (t_collided){
					collidedWithMonster = YES;
				} else {
					
					if (walkBPM >= runningThresholdBPM){
						
						if (walkBPM >= trippingThresholdBPM && playerCanMove == YES){
							playerCanMove = NO;
							[csl playSoundWithName:tripSoundName];
							// play an appropriate sound
							// stop player being able to move for x seconds
							[self performSelector:@selector(allowPlayerToMove) 
									   withObject:nil 
									   afterDelay:trippingTimePenalty];
						}
						[monstr monsterIsAlertedToCGPoint:playerPosition];
					}
				}
			}
			
			if (collidedWithMonster){
				[self eatenByMonster:monsterAttackSound];
				
			}
			
			// now update the MAP
			//[mapView updatePlayerLocation:playerPosition andCollectableLocation:collectablePt];
			
			
			// now update the SPATIALISED SOUNDS
			int max = [cslSounds count];
			for (size_t i=0; i < max; i++) {
				CslSpatialisedSound *snd = (CslSpatialisedSound *)[cslSounds objectAtIndex:i];
				[snd playerPositionHasChanged:playerPosition andAngle:playerAngle];
				
			}
		}
		// get the COLLECTABLE's location
		CGPoint collectablePt = [collectables location];
		// now get the MONSTERS location
		NSMutableArray *monsterLocs = [NSMutableArray arrayWithCapacity:0];
		for (size_t i=0; i<[monsters count]; i++) {
			MonsterNPC *monstr = [monsters objectAtIndex:i];
			[monsterLocs addObject:[NSValue valueWithCGPoint:[monstr location]]];
		}
		// now update the MAP
		[mapView updatePlayerLocation:playerPosition 
			   andCollectableLocation:collectablePt
				  andMonsterLocations:monsterLocs];
	}
}

- (void) eatenByMonster:(NSString *)snd
{
	gameIsActive = NO;
	_gameEndMode = @"eaten";
	
	[csl playSoundWithName:snd];
	
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oh dear" message:@"You were eaten by a monster! Oh noes." delegate:self cancelButtonTitle:nil otherButtonTitles:@"sob", nil];
	[alertView show];
	[alertView release];
	
	
}

- (void) runOutOfTime
{
	gameIsActive = NO;
	_gameEndMode = @"timeout";
	
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Oh dear" 
														message:@"You ran out of time!" 
													   delegate:self 
											  cancelButtonTitle:nil 
											  otherButtonTitles:@"sob", nil];
	[alertView show];
	[alertView release];
	
}

- (void) finishedLevel:(NSString *)reason
{
	NSLog(@"[SypVC finishedLevel] '%@'",reason);
	SyPAppDelegate *appDelegate = (SyPAppDelegate *)[[UIApplication sharedApplication] delegate];
	[appDelegate finishedLevel:reason];
}


- (void) startCountdownTimer
{
	if (!countdownTimer){
		countdownCounter = 30.0f;
		countdownTimer =  [NSTimer scheduledTimerWithTimeInterval:1.0f 
														   target:self 
														 selector:@selector(updateCountdownTimer) 
														 userInfo:nil 
														  repeats:YES
								];
		// call this straight away otherwise we have to wait for the first count to pass
		[self updateCountdownTimer];
	} else {
		NSLog(@"[SypVC startCountdownTimer] called, but it's already active.");
	}
}

- (void) updateCountdownTimer
{
	countdownCounter -= 1.0f;
	if (countdownCounter > 10.0f){
		// play general countdown sound
		[csl playSoundWithName:@"alm_slow"];
		
	} else if (countdownCounter > 0.0f) {
		// play enhanced countdown sound
		[csl playSoundWithName:@"alm_fst"];
	} else {
		// countdownCounter is at 0, so stop the counter
		[self stopCountdownTimer];
		// and end the level
		[self runOutOfTime];
	}
}

- (void) stopCountdownTimer
{
	if (countdownTimer){
		[countdownTimer invalidate];
		countdownTimer = nil;
	}
}

#pragma mark Cardinal Wipe GAME UI
/*

// Cardinal Swipe Controls (unused)
- (void) touchViewDidSwipeLeft:(id)touchView
{
	if (gameIsActive){
		NSLog(@"[SyPVC] touchViewDidSwipeLeft");
		[self rotatePlayer:-kPlayerRotationStep];
	}
}

// Cardinal Swipe Controls (unused)
- (void) touchViewDidSwipeRight:(id)touchView
{
	if (gameIsActive){
		NSLog(@"[SyPVC] touchViewDidSwipeRight");
		[self rotatePlayer:kPlayerRotationStep];
	}
}
*/

#pragma mark Colonel Panic's Wipe  GAME UI

- (void) allowPlayerToMove {
	playerCanMove = YES;
}

- (IBAction) didTapLeftFootButton:(id)sender
{
	if (gameIsActive){
		if (playerCanMove == YES){
			if ([self isLeftFoot] == NO){
				[self setIsLeftFoot:YES];
				
				//[snd_footstepsL stop];
				//[snd_footstepsL play];
				[self movePlayerForwardOneStep];
			}
		}
	}
}

- (IBAction) didTapRightFootButton:(id)sender
{
	if (gameIsActive){
		if (playerCanMove == YES){
			if ([self isLeftFoot] == YES){
			[self setIsLeftFoot:NO];
				
				//[snd_footstepsR stop];
				//[snd_footstepsR play];
				[self movePlayerForwardOneStep];
			}
		}
	}
}

// Swip delegate
- (void) touchDidStartSwipe:(CGPoint) startLoc
{
	if (gameIsActive){
		_playerAngleAtStartOfSwipe = playerAngle;
	}
}

- (void) touchDidMoveRelativeToStart:(CGPoint) movement
{
	if (gameIsActive){
		// we are landscape, so we treat y as a horizontal swipe
		float movementInPixels = movement.y;
		float newAngle = _playerAngleAtStartOfSwipe + (movementInPixels/4);
		[self rotatePlayerToFixedRotation:newAngle];
	}
}

#pragma mark Thumbalism GAME UI
/*
- (void) userDidMoveForwards:(NSNumber *)movementAmnt
{
	if (gameIsActive){
		// check against internal movement (or does GameView do this?)
		// no, it can't really...
		// + (NSTimer *)timerWithTimeInterval:(NSTimeInterval)seconds target:(id)target selector:(SEL)aSelector userInfo:(id)userInfo repeats:(BOOL)repeats
		
		// this needs to be slow (high) if the number is low and fast (low) if the number is high
		moveTimeInterval = 0.1;
		if (moveTimer){
			// already exists, so just let it update "next time"
			
			//[moveTimer invalidate];
			//moveTimer = nil;
		} else {
			moveTimer = [NSTimer timerWithTimeInterval:moveTimeInterval 
												target:self 
											  selector:@selector(autoWalkMoveForwardOneStep:) 
											  userInfo:nil 
											   repeats:NO];
			[moveTimer retain];
		}
	
	}
}

- (void) userDidStopMovement
{
	if (moveTimer){
		[moveTimer invalidate];
		moveTimer = nil;
	}
}

- (void)autoWalkMoveForwardOneStep:(NSTimer*)theTimer
{
	[self movePlayerForwardOneStep];
	if (moveTimer){
		// already exists, so just let it update "next time"
		
		[moveTimer release];
		[moveTimer invalidate];
		moveTimer = nil;
	}
	moveTimer = [NSTimer timerWithTimeInterval:moveTimeInterval 
										target:self 
									  selector:@selector(autoWalkMoveForwardOneStep:) 
									  userInfo:nil 
									   repeats:NO];
	[moveTimer retain];
}
*/
#pragma mark internal movement algorhythms

// @TODO - stop player going outside of boundary
- (void) movePlayerForwardOneStep
{
	NSString *sndName;
	BOOL found = NO;
	BOOL isFast = NO;
	FloorSpaceData *fsd;
	
	[self calculateTempo];
	if (walkBPM > runningThresholdBPM){
		isFast = YES;
	}
	
	float nx = playerPosition.x + playerVector.x;
	float ny = playerPosition.y + playerVector.y;
	
	//float 
	
	
	if ((nx >= 0 && nx <= gamePlayAreaSize.width) && (ny >= 0 && ny <= gamePlayAreaSize.height)){
		for (size_t i=0; i<[surfaceData count]; i++) {
			fsd = [surfaceData objectAtIndex:i];
			if ([fsd isPointWithinRects:playerPosition]){
				found = YES;
				
				if ([fsd isMonsterTrigger] || [fsd surfaceIsLoud]){
					// alert the monsters to the player
					// do we play a specific alert-sound here, or 
					// is the footstep sound enough (on top of the monster alert sound)?
					NSLog(@"[SypVC movePlayerForwardOneStep] floor was trigger, so alerting monsters");
					for (size_t m=0; m<[monsters count]; m++) {
						MonsterNPC *monstr = [monsters objectAtIndex:m];
						[monstr monsterIsAlertedToCGPoint:playerPosition];
					}
				}
				
				if ([fsd isTimerTrigger]){
					NSLog(@"[SypVC movePlayerForwardOneStep] floor was trigger, so starting timer");
					[self startCountdownTimer];
					
				}
				
				
				break;
			}
		}
		// at this point we need to check the floor we are on!
		if ([self isLeftFoot]){
			if (isPlayerFacingCollectable){
				sndName = @"ft_twds_L";
			} else {
				sndName = @"step_dirt_l_a";
			}
			if (found){
				if (isPlayerFacingCollectable){
					sndName = [fsd getLeftFootSoundFacing:isFast];
				} else {
					sndName = [fsd getLeftFootSound:isFast];
				}
			}
		} else {
			if (isPlayerFacingCollectable){
				sndName = @"ft_twds_R";
			} else {
				sndName = @"step_dirt_r_a";
			}
			if (found){
				if (isPlayerFacingCollectable){
					sndName = [fsd getRightFootSoundFacing:isFast];
				} else {
					sndName = [fsd getRightFootSound:isFast];
				}
			}
		}
		if (sndName){
			[csl playSoundWithName:sndName];
		}
		
		playerPosition.x += playerVector.x;
		playerPosition.y += playerVector.y;
	} else {
		//NSLog(@"[SyPVC movePlayerFowardOneStep] hit the wall");
		[csl playSoundWithName:@"wl_imp"];
	}
	[self updateSpatialisedSounds];
}

/** rotates the player a relative amount
 *
 */
- (void) rotatePlayer:(float)rotation
{
	[self rotatePlayerToFixedRotation:playerAngle+rotation];
}

- (void) rotatePlayerToFixedRotation:(float) rotation
{
	// clamp the rotation
	if (rotation > 360){
		rotation -= 360;
	} else if (rotation < 0){
		rotation += 360;
	}
	//rotation = min(0, <#const _Tp __b#>)
	playerAngle = rotation; // % 360;
	
	/*
	float max_angle = M_PI*2;
	if (playerAngle > max_angle){
		playerAngle = playerAngle - max_angle;
	} else if (playerAngle < 0){
		playerAngle = max_angle - playerAngle;
	}
	*/
	
	float playerAngleRadians = playerAngle*(M_PI/180.0f);
	
	// we know the angle and the distance, so we just need O & H
	// but there is that fiddly thing to do with radians
	playerVector.x = cos(playerAngleRadians) * playerMovement;
	playerVector.y = sin(playerAngleRadians) * playerMovement;
	
	
	//NSLog(@"[SyPVC rotatePlayerToFixedRotation:%0.2f] vector=%0.2fx%0.2f",playerAngle,playerVector.x,playerVector.y);
	
	[self updateSpatialisedSounds];
}

- (void) updateSpatialisedSounds
{
	playerHasMoved = YES;
}

- (void) showDebug
{
	if ([mapView isHidden]){
		[mapView setHidden:NO];
	} else {
		[mapView setHidden:YES];
	}
}

- (void) calculateTempo
{
	NSDate *dateNow = [NSDate dateWithTimeIntervalSinceNow:0];
	NSTimeInterval timeNow = [dateNow timeIntervalSinceReferenceDate];
	
	// compare against last entry in array - if the time difference is greater than 3 seconds then re-set the array
	[walkTimes addObject:[NSNumber numberWithDouble:timeNow]];
	
	/*
	NSMutableString *dbg = [NSMutableString stringWithCapacity:1];
	for (int j=0;j<[walkTimes count];j++){
		[dbg appendFormat:@"%0.2f,",[[walkTimes objectAtIndex:j] doubleValue]];
	}
	NSLog(@"added %0.2f to '%@'",timeNow,dbg);
	*/
	
	if ([walkTimes count] > 2){
		// keep the array to a manageable size.
		while ([walkTimes count] > 5) {
			[walkTimes removeObjectAtIndex:0];
		}
		
		float totalTime = 0;
		// now get the tempo from the last few walk times.
		for (int i=0; i<[walkTimes count]-1; i++) {
			NSTimeInterval time1 = [[walkTimes objectAtIndex:i] doubleValue];
			NSTimeInterval time2 = [[walkTimes objectAtIndex:(i+1)] doubleValue];
			NSTimeInterval difference = (time2-time1);
			totalTime += difference;
			//NSLog(@"[SypVC calcTempo] time1='%0.2f' time2='%0.2f' difference='%0.2f'",time1,time2,difference);
		}
		float avgTime = totalTime/[walkTimes count];
		//avgTime /= 1000.0f;
		float bpm = 60.0f / avgTime;
		
		//NSLog(@"[SypVC calcTempo] walk BPM is '%0.2f' avgTime='%0.4f' totalTime='%0.2f' total='%i'",bpm,avgTime,totalTime,[walkTimes count]);
		
		walkBPM = bpm;
		// minute / bpm = timeInt
		// minute = bpm * timeInt
		// minute / timeInt = bpm
	} else {
		walkBPM = 30.0f; // set it to a low number
	}
}

#pragma mark alert delegate functions

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	[self performSelector:@selector(finishedLevel:) withObject:_gameEndMode afterDelay:1.0f];
}

#pragma mark monster delegate functions

- (void) monsterNPC: (MonsterNPC *) monster didEatPlayerAtCGPoint:(CGPoint)pt
{
	NSLog(@"[SyPVC] monsterNPC - player eaten");
	NSString *attackSnd = [monster attackSoundName];
	[self eatenByMonster:attackSnd];
}

@end
