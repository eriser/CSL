//
//  CslStereoSound.h
//  SyP
//
//  Created by Adam Hoyle on 22/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <Foundation/Foundation.h>

#define AMP_SCALE 0.1f

@interface CslStereoSound : NSObject {
	void * soundfile;		// CASoundFile 
	void * panner;			// Panner 

	NSTimeInterval lastPlayed;
}

//@property (nonatomic,retain) NSTimeInterval lastPlayed;

- (void) setSound:(NSString *)newSoundFileName;
- (void) clearSound;
- (void) playFromStart;
- (void) playLooping;
- (void) stopSound;

// this allows us to do prioritisation on the sounds.

- (NSTimeInterval) lastPlayed;
- (NSComparisonResult) compareLastPlayed:(CslStereoSound *)snd;

@end
