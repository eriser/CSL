//
//  MonsterNPC.h
//  SyP
//
//  Created by Adam Hoyle on 25/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CslSpatialisedSound.h"
//#import "MonsterNPC.h"

@protocol MonsterDelegate <NSObject>

- (void) monsterNPC: (id *) monster didEatPlayerAtCGPoint:(CGPoint)pt;

@end

@interface MonsterNPC : NSObject {
	CGPoint location;
	CGPoint lastPlayerLoc;
	CGFloat lastPlayerAngle;
	CGPoint targetLocation;
	CslSpatialisedSound *cslSnd;
	
	BOOL isActive;
	BOOL isHeadingForTarget;
	
	NSMutableArray *updateTimes; // used for determining speed of player movement (eg do we chase)
	
	NSTimer *nextStepTimer;
	
	NSString *stillSound;
	NSString *patrolSound;
	NSString *awareSound;
	NSString *chaseSound;
	NSString *notThereSound;
	NSString *attackSound;
	
	CGFloat maxHearingDistance;
	
	BOOL chasePlayer;
	
	id<MonsterDelegate> *_delegate;
	
	int pathPointer;
	NSArray *pathDetails;
	
	NSTimer *startWalkingTimer;
	CGFloat walkSpeedInSeconds;
	CGFloat runSpeedInSeconds;
}


- (id) initWithSpatialisedSound:(CslSpatialisedSound *)spatSnd;
- (NSDictionary *) playerPositionHasChanged:(CGPoint)loc andAngle:(CGFloat)angle;
- (BOOL) monsterIsAlertedToCGPoint:(CGPoint)loc;
- (CGPoint) location;
- (NSString *)attackSoundName;
- (void) setDelegate: (id<MonsterDelegate>) delegate;

- (void) startRunning;
- (void) startMovingInSeconds:(float) seconds;

@end

