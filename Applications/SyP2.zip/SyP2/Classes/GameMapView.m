//
//  GameMapView.m
//  SyP
//
//  Created by Adam Hoyle on 30/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import "GameMapView.h"
#import "ImageManipulation.h"
#import "FloorSpaceData.h"


@implementation GameMapView


- (id)initWithFrame:(CGRect)frame andGameSize:(CGSize)size {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
		tileSize = frame.size.width/size.width; // how big to make a tile
		gameDimensions = size;
		
		NSLog(@"creating GameMapView tileSize is '%0.2f' gameDimensions='%0.2f,%0.2f'",tileSize,gameDimensions.width,gameDimensions.height);
		
		CGSize itmsize = CGSizeMake(gameDimensions.width*tileSize, gameDimensions.height*tileSize);
		itemsCanvas = [ImageManipulation getContextWithSize:itmsize];
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void) drawLayer:(CGLayerRef)thelayer inContext:(CGContextRef)theContext
{
	//NSLog(@"drawLayer");
	
	//CGSize s = CGLayerGetSize(thelayer);  // this didn't work (naughty layer)
	CGSize s = CGLayerGetSize(surfacesLayer);
	CGRect c = CGRectMake(0, 0, s.width, s.height);
	
	//NSLog(@"[GameMapView] drawLayer rect.size=(%0.2f,%0.2f)",s.width,s.height);
	
	// first draw the surfaces
	CGContextDrawLayerInRect(theContext, c, surfacesLayer);
	
	// then render on the monsters, collectables and the player
	CGImageRef cImg = CGBitmapContextCreateImage( itemsCanvas );
	CGContextDrawImage(theContext, c, cImg);
	
	// release anything created in this method
	CGImageRelease(cImg);
}


- (void)dealloc {
	if (itemsCanvas){
		CGContextRelease(itemsCanvas);
		itemsCanvas = nil;
	}
	if (surfacesLayer){
		CGLayerRelease(surfacesLayer);
		surfacesLayer = nil;
	}
    [super dealloc];
}


// array should only contain instances of FloorSpaceData
- (void) renderSurfaces:(NSArray *)arr
{
	NSLog(@"[GameMapView] renderSurfaces");
	NSArray *cgRectArr;
	CGRect aRect;
	CGRect bRect;
	//float tileSize = 4.0f; // how big to make a tile
	CGSize size = CGSizeMake(gameDimensions.width*tileSize, gameDimensions.height*tileSize);
	CGContextRef canvas = [ImageManipulation getContextWithSize:size];
	
	// fill in the background with BG Colour
	CGContextSetRGBFillColor(canvas, 0.2f, 0.2f, 0.2f, 1.0f);
	//CGContextSetFillColorWithColor(canvas, CGColorCreate(<#CGColorSpaceRef space#>, <#const CGFloat [] components#>)
	CGContextFillRect(canvas, CGRectMake(0, 0, size.width, size.height));
	
	float colourInc = 0.0f;
	// set the fill colour to GREEN
	CGContextSetRGBFillColor(canvas, 0.0, 1.0f, 0.0, 0.8f);
	
	
	// run through and draw in the rects
	//for (size_t i=0; i < [arr count]; i++) {
	for (int i=[arr count]-1; i >= 0 ; i--) {
		//NSLog(@"renderSurfaces %i",i);
		CGContextSetRGBFillColor(canvas, colourInc, 1.0f-colourInc, 0.0, 0.8f);
		// get the fsd's rects
		FloorSpaceData *fsd = [arr objectAtIndex:i];
		cgRectArr = [fsd floorRects];
		// @TODO should prolly colour the canvas according to the type of surface(?)
		for (size_t j=0; j < [cgRectArr count]; j++) {
			aRect = [(NSValue *)[cgRectArr objectAtIndex:j] CGRectValue];
			bRect = CGRectMake(aRect.origin.x*tileSize, aRect.origin.y*tileSize,
							   aRect.size.width*tileSize, aRect.size.height*tileSize);
			NSLog(@"[GameMapView] rendering rect at %0.2fx%0.2f %0.2f/%0.2f",bRect.origin.x,bRect.origin.y,bRect.size.width,bRect.size.height);
			CGContextFillRect(canvas, bRect);
		}
		colourInc += 0.1f;
	}
	// cos this should only get called infrequently,
	// let's cache the bitmap into a layer.
	// so it's faster to draw
	if (surfacesLayer){
		CGLayerRelease(surfacesLayer);
		surfacesLayer = nil;
	}
	CGImageRef cImg = CGBitmapContextCreateImage( canvas );
	surfacesLayer = [self getCGLayerFromCGImage:cImg withContext:canvas];
	CGLayerRetain( surfacesLayer );
	
	// release everything we've created for this method
	CGContextRelease(canvas);
	CGImageRelease(cImg);
	
	[self setNeedsDisplay];
}

- (void) updatePlayerLocation:(CGPoint)playerLoc andCollectableLocation:(CGPoint)collectableLoc andMonsterLocations:(NSArray *)monsterLocs
{	
	NSLog(@"");
	// clear the context
	//float tileSize = 4.0f; // how big to make a tile
	float tileMargin = 0.5f; // how much margin to take off the tileSize on each side
	//CGSize size = // CGSizeMake(24.0f*tileSize, 24.0f*tileSize);
	CGSize size = CGSizeMake(gameDimensions.width*tileSize, gameDimensions.height*tileSize);
	CGContextClearRect(itemsCanvas,CGRectMake(0.0, 0.0, size.width, size.height));
	
	CGRect playerRect = CGRectMake((playerLoc.x*tileSize)-tileMargin,
								   (playerLoc.y*tileSize)-tileMargin, 
								   tileSize-tileMargin, 
								   tileSize-tileMargin);
	// set the fill colour to GREEN
	CGContextSetRGBFillColor(itemsCanvas, 1.0, 1.0, 0.0, 0.8f);
	CGContextFillRect(itemsCanvas, playerRect);
	
	
	//NSLog(@"updatePlayerLocation playerRect='%0.2f,%0.2f,%0.2f,%0.2f'",playerRect.origin.x,playerRect.origin.y,playerRect.size.width,playerRect.size.height);
	
	
	
	CGRect collectableRect = CGRectMake((collectableLoc.x*tileSize)-tileMargin,
										(collectableLoc.y*tileSize)-tileMargin, 
										tileSize-tileMargin, 
										tileSize-tileMargin);
	// set the fill colour to YELLOW
	CGContextSetRGBFillColor(itemsCanvas, 0.0, 1.0, 1.0, 0.8f);
	CGContextFillRect(itemsCanvas, collectableRect);
	
	int monsterMax = [monsterLocs count];
	for (size_t i=0; i < monsterMax; i++) {
		CGPoint monsterPt = [(NSValue *)[monsterLocs objectAtIndex:i] CGPointValue];
		
		CGRect monsterRect = CGRectMake((monsterPt.x*tileSize)-tileMargin,
										(monsterPt.y*tileSize)-tileMargin, 
										tileSize-tileMargin, 
										tileSize-tileMargin);
		// set the fill colour to RED
		CGContextSetRGBFillColor(itemsCanvas, 1.0, 0.0, 0.0, 0.8f);
		CGContextFillRect(itemsCanvas, monsterRect);
		
	}
	
	
	[self setNeedsDisplay];
}

- (CGLayerRef) getCGLayerFromCGImage:(CGImageRef)img withContext:(CGContextRef)context
{
	CGFloat width = CGImageGetWidth( img );
	CGFloat height = CGImageGetHeight( img );
	CGSize size = CGSizeMake( width, height );
	CGLayerRef cgl = CGLayerCreateWithContext(context, size, NULL);
	CGContextRef cglcontext = CGLayerGetContext(cgl);
	CGContextDrawImage(cglcontext, CGRectMake(0, 0, width, height), img);
	return cgl;
}

@end
