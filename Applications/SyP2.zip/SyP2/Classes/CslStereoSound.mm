//
//  CslStereoSound.m
//  SyP
//
//  Created by Adam Hoyle on 22/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import "CslStereoSound.h"

#include "CSL_Includes.h"
//#include "iphoneIO.h"

using namespace csl;

extern Mixer * gOutMix;			// master output mixer
//extern iPhoneIO * gIO;			// the IO driver object

@implementation CslStereoSound

using namespace csl;

- (void) dealloc
{
	[super dealloc];
	[self clearSound];
}

- (void) setSound:(NSString *)newSoundFileName
{
	[self clearSound];
	
	if (![newSoundFileName isEqual:@""]) {
						// now get the sound file
		NSBundle * bundle = [NSBundle mainBundle];
		NSString *filename = [bundle pathForResource:newSoundFileName ofType:@"caf"];
		if (filename) {
			NSLog(@"[CslStereoSnd] addingSound '%@.caf'",newSoundFileName);
						// get its name for c++
			const char * sampName = [filename cStringUsingEncoding: NSASCIIStringEncoding];
						// open and read the sound file
			CASoundFile *sndfile = new CASoundFile(sampName);
			sndfile->openForRead();
			sndfile->dump();
			if (sndfile->channels() == 2) {			// stereo case
				NSLog(@"[CslStereoSnd setSound] adding snd to mixer %x", gOutMix);
				gOutMix->addInput(*sndfile);				// plug the sndfile into the mixer
				gOutMix->scaleInput(*sndfile,  AMP_SCALE);
			//	gIO->setRoot(*sndfile);						// pass the CSL mixer to the IO
				soundfile = sndfile;
			} else if (sndfile->channels() == 1) {	// mono case
				float pos = 1.0f;
				if (strstr(sampName, "_L") || strstr(sampName, "_l"))
					pos = -1.0f;
				NSLog(@"[CslStereoSnd setSound] adding panner (%g) to mixer %x", pos, gOutMix);
				Panner * pan = new Panner(*sndfile, pos);
				gOutMix->addInput(*pan);					// plug the sndfile into the mixer
				gOutMix->scaleInput(*pan,  AMP_SCALE);
				soundfile = sndfile;
				panner = pan;
			}	
		} else {
			NSLog(@"[CslStereoSnd] error adding sound '%@.caf' - not found",newSoundFileName);
		}
	}
}

- (void) clearSound
{
	if (soundfile) {				
		CASoundFile * sndfile = (CASoundFile*)soundfile;
			//NSLog(@"[cslSnd processNewSoundFile] about to call setToEnd on sndfile");
		sndfile->setToEnd(); // does this stop the file playing?
		if (panner) {
			Panner * pan = (Panner *) panner;
			gOutMix->removeInput(pan);
			delete pan;
		} else {
		gOutMix->removeInput(sndfile);
		}
		delete sndfile;

//	} else {
//		NSLog(@"[CslStereoSnd clearSound] couldn't access sndfile");
	}
	soundfile = nil;
	panner = nil;

}

- (void) playFromStart
{
	if (soundfile){
		NSLog(@"[CslStereoSnd playFromStart]");
		CASoundFile *sfile = (CASoundFile*)soundfile;
		//sfile->seekTo(0,kPositionStart);
		sfile->trigger();
		// update this, so that the manager can manage (and remove) old sounds.
		lastPlayed = [[NSDate date] timeIntervalSince1970];
	} else {
		NSLog(@"[CslStereoSnd playFromStart] no soundfile :'(");
	}
}

- (void) playLooping
{
	if (soundfile){
		NSLog(@"[CslStereoSnd playLooping]");
		CASoundFile *sfile = (CASoundFile*)soundfile;
		//sfile->seekTo(0,kPositionStart);
		sfile->setIsLooping(true);
		sfile->trigger();
		// update this, so that the manager can manage (and remove) old sounds.
		// should really set this very far in the future to avoid it being cleared.
		lastPlayed = [[NSDate date] timeIntervalSince1970];
	} else {
		NSLog(@"[CslStereoSnd playLooping] no soundfile :'(");
	}
}

- (void) stopSound
{
	if (soundfile){
		NSLog(@"[CslStereoSnd stopSound]");
		CASoundFile *sfile = (CASoundFile*)soundfile;
		// stop the sound playing.
		sfile->setIsLooping(false);
		sfile->setToEnd();
		// update this, so that the manager can manage (and remove) old sounds.
		// could/should set this to a very old date, so it gets cleared first.
		//lastPlayed = [[NSDate date] timeIntervalSince1970];
	} else {
		NSLog(@"[CslStereoSnd stopSound] no soundfile :'(");
	}
}

- (NSTimeInterval) lastPlayed
{
	return lastPlayed;
}

- (NSComparisonResult) compareLastPlayed:(CslStereoSound *)snd
{
	NSTimeInterval mine = lastPlayed;
	NSTimeInterval theirs = [snd lastPlayed];
	//The comparator method should return NSOrderedAscending if the receiver is smaller than the argument,
	//NSOrderedDescending if the receiver is larger than the argument,
	//and NSOrderedSame if they are equal.
	if (mine < theirs){
		return NSOrderedAscending;
	} else if (mine > theirs){
		return NSOrderedDescending;
	} else {
		return NSOrderedSame;
	}
}

@end
