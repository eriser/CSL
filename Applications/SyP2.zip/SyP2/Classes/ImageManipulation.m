//
//  ImageManipulation.m
//  mugshot
//
//  Created by Adam Hoyle on 12/01/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import "ImageManipulation.h"


const float 	PI = 3.14159265358979323846f;

@implementation ImageManipulation

#define BEST_BYTE_ALIGNMENT 16
#define COMPUTE_BEST_BYTES_ROW(bpr) \
( ( (bpr) + (BEST_BYTE_ALIGNMENT-1) ) & ~(BEST_BYTE_ALIGNMENT-1) )

+ (CGContextRef) getContextWithSize:(CGSize)theSize
{
	size_t width = theSize.width;
	size_t height = theSize.height;
	size_t bitsPerComponent = 8;
	size_t bytesPerRow = width * 4;
	bytesPerRow = COMPUTE_BEST_BYTES_ROW( bytesPerRow );
	CGContextRef theContext = CGBitmapContextCreate( NULL, width, 
													height, 
													bitsPerComponent, 
													bytesPerRow,
													CGColorSpaceCreateDeviceRGB(), 
													kCGImageAlphaPremultipliedFirst );
	return theContext;
}

// not quite right, cos it leaves a white space at the bottom(!)
+ (UIImage *) scaleImage:(UIImage *)img toSize:(CGSize)finalSize
{
	NSLog(@"scale image - start");
	// get the CGImage from the UIImage
	CGImageRef cgimage = [img CGImage];
	// create the drawing context
	NSLog(@"scale image - create the drawing context");
	float width = finalSize.width;
	float height = finalSize.height;
	CGContextRef theContext = [ImageManipulation getContextWithSize:CGSizeMake(width,height)];
	// by default it appear that the image is being pasted in 90 rotated, so we need
	// to fix that
	CGContextRotateCTM( theContext, -(90*(PI/180)));
	CGContextTranslateCTM( theContext, -(float)height, 0);
	
	
	//CGFloat xscale = width / (float)CGImageGetWidth(cgimage);
	//CGFloat yscale = height / (float)CGImageGetHeight(cgimage);
	CGFloat xscale = height / (float)CGImageGetWidth(cgimage);
	CGFloat yscale = width / (float)CGImageGetHeight(cgimage);
	
	NSLog(@"scale image - set scale xs=%0.2f ys=%0.2f",xscale,yscale);
	
	CGContextScaleCTM( theContext, yscale, xscale);
	
	NSLog(@"scale image - draw image");
	CGRect rect = CGRectMake(0,0,CGImageGetWidth(cgimage),CGImageGetHeight(cgimage));
	CGContextDrawImage(theContext, rect, cgimage);
	
	CGImageRef cachedImage = CGBitmapContextCreateImage(theContext);
	CGContextRelease(theContext);
	NSLog(@"scale image - saved image is %ix%i",CGImageGetWidth(cachedImage),CGImageGetHeight(cachedImage));
	//[self saveCachedImage:cachedImage];
	UIImage *retImage = [UIImage imageWithCGImage:cachedImage];
	CGImageRelease(cachedImage);
	
	//CGImageRelease(cgimage);
	NSLog(@"scale image - done");
	return retImage;
}

+ (UIImage *) scaleImage:(UIImage *)img toSize:(CGSize)finalSize withCropRect:(CGRect)cropRect respectFinalSizeAspectRatio:(BOOL) respectRatio
{
	// get the CGImage from the UIImage
	
	UIImage *anImg = [ImageManipulation scaleAndRotateImage:img maxResolution:20000];
	CGImageRef cgimage = [anImg CGImage];
	
	//float owidth = CGImageGetWidth(cgimage);
	//float oheight = CGImageGetHeight(cgimage);
	float width = finalSize.width;
	float height = finalSize.height;
	NSLog(@"scaling to %0.0fx%0.0f",width,height);
	// create the drawing context
	CGContextRef theContext = [ImageManipulation getContextWithSize:CGSizeMake(width,height)];
	NSLog(@"scaleImage - initial= %0.0fx%0.0f %0.0fx%0.0f ",cropRect.origin.x,cropRect.origin.y,cropRect.size.width,cropRect.size.height);
	
	if (respectRatio){
		// check that the cropRect is the same aspect ratio as the the scaleSize
		float finalRatio = finalSize.width / finalSize.height;
		float cropRatio = cropRect.size.width / cropRect.size.height;
		//NSLog(@"scale image - finalRatio=%0.2f cropRatio=%0.2f",finalRatio,cropRatio);
		if (finalRatio != cropRatio){
			float newHeight = cropRect.size.height / finalRatio;
			float origHeight = (float)CGImageGetWidth(cgimage);
			float diff = (newHeight - cropRect.size.height)/2.0f;
			float yp = (float)cropRect.origin.y - diff;
			NSLog(@"scaleImage - cropRect.origin.y=%0.1f yp=%0.1f diff=%0.1f newHeight=%0.1f ",(float)cropRect.origin.y,yp,diff,newHeight);
			// check that the new height won't go over the edge of the original rect
			if ((yp + newHeight) > origHeight){
				NSLog(@"the new position is outside of the original height - need to adjust!!");
				//yp = origHeight - newHeight;
			}
			/* */
			cropRect = CGRectMake(cropRect.origin.x, yp, cropRect.size.width, newHeight);
		}
	}
		
	NSLog(@"scaleImage - converted to = %0.0fx%0.0f %0.0fx%0.0f ",cropRect.origin.x,cropRect.origin.y,cropRect.size.width,cropRect.size.height);
	/* 
	// invert the x & y positions of the cropRect
	//cropRect.origin.x = cropRect.size.width-cropRect.origin.x;
	//cropRect.origin.y = cropRect.size.height-cropRect.origin.y;
	cropRect = CGRectMake(cropRect.origin.x, oheight-cropRect.origin.y,
						  cropRect.size.width, cropRect.size.height);

	NSLog(@"cropRect after= %0.0fx%0.0f %0.0fx%0.0f ",cropRect.origin.x,cropRect.origin.y,cropRect.size.width,cropRect.size.height);
	*/
	
	// create the subimage
	CGImageRef subimage = CGImageCreateWithImageInRect (cgimage, cropRect);
	
	NSLog(@"created subimage, which is  %ix%i",CGImageGetWidth(subimage),CGImageGetHeight(subimage));
	/*
	// by default it appear that the image is being pasted in 90 rotated, so we need to fix that (grr)
	CGContextRotateCTM( theContext, -(90*(M_PI/180)));
	CGContextTranslateCTM( theContext, -(float)height, 0);
	*/
	CGRect rect = CGRectMake(0,0,width,height); //CGImageGetWidth(subimage),CGImageGetHeight(subimage));
	
	//CGContextSetAlpha(theContext, 0.7);
	// now draw the image
	//CGRect rect = CGRectMake(0,0,width,height); //CGImageGetWidth(subimage),CGImageGetHeight(subimage));
	CGContextDrawImage(theContext, rect, subimage);
	/*
	// and as a result we have to mess around with the scale values (otherwise the scaling is wrong)
	CGFloat xscale = width / (float)CGImageGetWidth(subimage);
	CGFloat yscale = height / (float)CGImageGetHeight(subimage);
	CGContextScaleCTM( theContext, yscale, xscale);
	NSLog(@"scale image - set scale xs=%0.2f ys=%0.2f",xscale,yscale);
	*/
	/*
	CGContextSetAlpha(theContext, 0.4);
	 */
	// now draw the image
	//CGRect rect = CGRectMake(100,100,200,200); //width,height); //CGImageGetWidth(subimage),CGImageGetHeight(subimage));
	//CGContextDrawImage(theContext, rect, subimage);
	
	// now get the image out of the context and save it to a UIImage
	CGImageRef cachedImage = CGBitmapContextCreateImage(theContext);
	UIImage *retImage = [UIImage imageWithCGImage:cachedImage];
	NSLog(@"scale image - saved image is %ix%i",CGImageGetWidth(cachedImage),CGImageGetHeight(cachedImage));
	
	// release any remaining CG objects
	CGImageRelease(cachedImage);
	//CGImageRelease(cgimage);
	
	// and finally, return the UIImage
	return retImage;
}


// from http://discussions.apple.com/message.jspa?messageID=7276709 
+ (UIImage *)scaleAndRotateImage:(UIImage *)image maxResolution:(int)max
{
	int kMaxResolution = max; // 2000; // massive, so we don't use it at the moment (just need to make sure the code works first)
	 
	 CGImageRef imgRef = image.CGImage;
	 
	 CGFloat width = CGImageGetWidth(imgRef);
	 CGFloat height = CGImageGetHeight(imgRef);
	 
	 CGAffineTransform transform = CGAffineTransformIdentity;
	 CGRect bounds = CGRectMake(0, 0, width, height);
	 if (width > kMaxResolution || height > kMaxResolution) {
		 CGFloat ratio = width/height;
		 if (ratio > 1) {
			 bounds.size.width = kMaxResolution;
			 bounds.size.height = bounds.size.width / ratio;
		 }
		 else {
			 bounds.size.height = kMaxResolution;
			 bounds.size.width = bounds.size.height * ratio;
		 }
	 }
	 
	 CGFloat scaleRatio = bounds.size.width / width;

	 CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
	 CGFloat boundHeight;
	 UIImageOrientation orient = image.imageOrientation;
	 switch(orient) {
		 
		 case UIImageOrientationUp: //EXIF = 1
			 transform = CGAffineTransformIdentity;
			 break;
		 
		 case UIImageOrientationUpMirrored: //EXIF = 2
			 transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
			 transform = CGAffineTransformScale(transform, -1.0, 1.0);
			 break;
		 
		 case UIImageOrientationDown: //EXIF = 3
			 transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
			 transform = CGAffineTransformRotate(transform, M_PI);
			 break;
		 
		 case UIImageOrientationDownMirrored: //EXIF = 4
			 transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
			 transform = CGAffineTransformScale(transform, 1.0, -1.0);
			 break;
		 
		 case UIImageOrientationLeftMirrored: //EXIF = 5
			 boundHeight = bounds.size.height;
			 bounds.size.height = bounds.size.width;
			 bounds.size.width = boundHeight;
			 transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
			 transform = CGAffineTransformScale(transform, -1.0, 1.0);
			 transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
			 break;
		 
		 case UIImageOrientationLeft: //EXIF = 6
			 boundHeight = bounds.size.height;
			 bounds.size.height = bounds.size.width;
			 bounds.size.width = boundHeight;
			 transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
			 transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
			 break;
		 
		 case UIImageOrientationRightMirrored: //EXIF = 7
			 boundHeight = bounds.size.height;
			 bounds.size.height = bounds.size.width;
			 bounds.size.width = boundHeight;
			 transform = CGAffineTransformMakeScale(-1.0, 1.0);
			 transform = CGAffineTransformRotate(transform, M_PI / 2.0);
			 break;
			 
		 case UIImageOrientationRight: //EXIF = 8
			 boundHeight = bounds.size.height;
			 bounds.size.height = bounds.size.width;
			 bounds.size.width = boundHeight;
			 transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
			 transform = CGAffineTransformRotate(transform, M_PI / 2.0);
			 break;
		 
		 default:
			 //[NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
			// transform = CGAffineTransformIdentity;
			 break;
	 }
	 
	 UIGraphicsBeginImageContext(bounds.size);
	 
	 CGContextRef context = UIGraphicsGetCurrentContext();
	 
	 if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
		 CGContextScaleCTM(context, -scaleRatio, scaleRatio);
		 CGContextTranslateCTM(context, -height, 0);
	 }
	 else {
		 CGContextScaleCTM(context, scaleRatio, -scaleRatio);
		 CGContextTranslateCTM(context, 0, -height);
	 }
	 
	 CGContextConcatCTM(context, transform);
	 
	 CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
	 UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
	 UIGraphicsEndImageContext();
	 
	 return imageCopy;
}

static const char encodingTable[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

+ (NSString *)base64EncodeNSData:(NSData *)srcData
{
	
	if ([srcData length] == 0)
		return @"";
	
    char *characters = malloc((([srcData length] + 2) / 3) * 4);
	if (characters == NULL)
		return nil;
	NSUInteger length = 0;
	
	NSUInteger i = 0;
	while (i < [srcData length])
	{
		char buffer[3] = {0,0,0};
		short bufferLength = 0;
		while (bufferLength < 3 && i < [srcData length])
			buffer[bufferLength++] = ((char *)[srcData bytes])[i++];
		
		//  Encode the bytes in the buffer to four characters, including padding "=" characters if necessary.
		characters[length++] = encodingTable[(buffer[0] & 0xFC) >> 2];
		characters[length++] = encodingTable[((buffer[0] & 0x03) << 4) | ((buffer[1] & 0xF0) >> 4)];
		if (bufferLength > 1)
			characters[length++] = encodingTable[((buffer[1] & 0x0F) << 2) | ((buffer[2] & 0xC0) >> 6)];
		else characters[length++] = '=';
		if (bufferLength > 2)
			characters[length++] = encodingTable[buffer[2] & 0x3F];
		else characters[length++] = '=';	
	}
	
	return [[[NSString alloc] initWithBytesNoCopy:characters length:length encoding:NSASCIIStringEncoding freeWhenDone:YES] autorelease];
}

- (CGLayerRef) getCGLayerFromCGImage:(CGImageRef)img withContext:(CGContextRef)context
{
	CGFloat width = CGImageGetWidth( img );
	CGFloat height = CGImageGetHeight( img );
	CGSize size = CGSizeMake( width, height );
	CGLayerRef cgl = CGLayerCreateWithContext(context, size, NULL);
	CGContextRef cglcontext = CGLayerGetContext(cgl);
	CGContextDrawImage(cglcontext, CGRectMake(0, 0, width, height), img);
	return cgl;
}

@end
