//
//  CollectableLinearManager.m
//  SyP
//
//  Created by Adam Hoyle on 18/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import "CollectableLinearManager.h"

@implementation CollectableLinearManager

- (id) initWithGameLevel:(GameLevel *)gLevel andSpatialisedSound:(CslSpatialisedSound *)snd
{
	if (self = [super init]){
		gameLevel = [gLevel retain];
		cslSnd = snd;
		collectableCounter = -1;
		isPlayerAlreadyFacingCollectable = NO;
		
		[self nextCollectable];
	}
	return self;
}

- (void) dealloc
{
	if (gameLevel){
		[gameLevel release];
		gameLevel = nil;
	}
	[super dealloc];
}

- (void) nextCollectable
{
	collectableCounter++;
	NSLog(@"[CollectableLinearManager] nextCollectable counter='%i' total='%i'",collectableCounter,[gameLevel getTotalCollectables]);
	if (collectableCounter < [gameLevel getTotalCollectables]){
		
		isPlayerAlreadyFacingCollectable = NO;
		
		NSDictionary *dict = [gameLevel getCollectableDict:collectableCounter];
		
		location = CGPointMake([[dict objectForKey:@"x"] floatValue],[[dict objectForKey:@"y"] floatValue]);
		if (collectableType) {
			[collectableType release];
		}
		collectableType = [[dict objectForKey:@"type"] retain];
		outroSound = [[dict objectForKey:@"outroSound"] retain];
		
		// play the intro sound and then loop the loop sound
		NSArray *arrayOfSoundFiles = [NSArray arrayWithObjects:[dict objectForKey:@"introSound"],[dict objectForKey:@"sound"],nil];
		[cslSnd playArrayOfSoundFiles:arrayOfSoundFiles];
		//[cslSnd changeSoundFile:[dict objectForKey:@"sound"]]; // play the main sound (on loop) 
		[cslSnd updateLocation:location];
		
		isActive = YES;
		
		NSLog(@"");
		
	} else {
		NSLog(@"[CollectableLinearManager] We've run out of collectables!");
		[cslSnd changeSoundFile:@""];
		isActive = NO;
	}
}


- (NSDictionary *) playerPositionHasChanged:(CGPoint)loc andAngle:(CGFloat)angle
{
	BOOL collected = NO;
	BOOL isPlayerNewlyFacingCollectable = NO;
	float thetaDegrees = 180.0f;
	if (isActive){
		float adj = loc.x - location.x;
		float opp = loc.y - location.y;
		float dist = sqrt((opp*opp)+(adj*adj));
		
		float thetaRads = atan(opp/adj);
		thetaDegrees = thetaRads * (180.0f/M_PI);
		float oDegrees = thetaDegrees;
		thetaDegrees -= angle; //[angle floatValue];
		if (thetaDegrees > 360){
			thetaDegrees -= 360;
		} else if (thetaDegrees < 0){
			thetaDegrees += 360;
		}
		// compensate for figuring out angle and radians/180 issue
		
		// added by atom to correct angle offset
		thetaDegrees += 180;
		if (thetaDegrees > 360) thetaDegrees -= 360;
		
		if (adj < 0) thetaDegrees += 180;
		if (thetaDegrees < 0){
			thetaDegrees += 360;
		} else if (thetaDegrees > 360){
			thetaDegrees -= 360;
		}
		// end added by atom to correct angle offset
		/*
		if (adj < 0){
			thetaDegrees += 180;
			if (thetaDegrees > 360){
				thetaDegrees -= 360;
			} else if (thetaDegrees < 0){
				thetaDegrees += 360;
			}
		}
		 */
		if ((thetaDegrees < 361 && thetaDegrees > 355) || (thetaDegrees > -1 && thetaDegrees < 5)){
			// we are facing the target with margin of 10 degrees.
			if (isPlayerAlreadyFacingCollectable == NO){
				isPlayerNewlyFacingCollectable = YES;
			}
			isPlayerAlreadyFacingCollectable = YES;
		} else {
			isPlayerAlreadyFacingCollectable = NO;
		}
		
		//NSLog(@"[CollectableLinearManager] dist=%0.2f relativeAngle=%0.2f playerLookingAngle=%0.2f oDegrees=%0.2f (newly-facing='%d' facing='%d')",dist,thetaDegrees,angle,oDegrees,isPlayerNewlyFacingCollectable,isPlayerAlreadyFacingCollectable);
		if (dist < 1.5f){
			collected = YES;
			// clear the sound file
			[cslSnd changeSoundFile:@""];
		}
	}
	NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
						  [NSNumber numberWithBool:collected],@"collected",
						  [NSValue valueWithCGPoint:location],@"location",
						  [NSNumber numberWithFloat:thetaDegrees],@"angle",
						  [NSNumber numberWithBool:isPlayerNewlyFacingCollectable],@"newlyFacingCollectable",
						  [NSNumber numberWithBool:isPlayerAlreadyFacingCollectable],@"facingCollectable",
						  collectableType,@"type",
						  outroSound,@"outroSound",
						  nil
						 ];
	if (collected == YES){
		isActive = NO;
		[self performSelector:@selector(nextCollectable) withObject:nil afterDelay:2.0f];
		//[self nextCollectable];
	}
	return dict;
}

- (CGPoint) location
{
	return CGPointMake(location.x,location.y);
}

@end
