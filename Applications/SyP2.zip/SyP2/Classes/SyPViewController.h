//
//  SyPViewController.h
//  SyP
//
//  Created by Adam Hoyle on 28/09/2009.
//  Copyright Do-Tank 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "CslSpatialisedSound.h"
#import "CslSpatialisedManager.h"
#import <AVFoundation/AVFoundation.h>

#import "GameLevel.h"
#import "CollectableLinearManager.h"
#import "GameMapView.h"
#import "MonsterNPC.h"

@interface SyPViewController : UIViewController <MonsterDelegate>{
	// 
	NSTimer *enterFrameTimer;
	AVAudioPlayer *snd_footstepsL;
	AVAudioPlayer *snd_footstepsR;
	BOOL isLeftFoot;
	
	NSMutableArray *threads;
	NSMutableArray *cslSounds;
	NSMutableArray *surfaceData;
	
	CGPoint playerPosition;
	CGPoint playerVector;
	CGFloat playerAngle;
	CGFloat playerMovement;
	
	// Colonel Panic's Wipe
	float _playerAngleAtStartOfSwipe;
	
	// Thumbalism
	NSTimer *moveTimer;
	NSTimeInterval moveTimeInterval;
	
	CslSpatialisedManager * csl;
	CollectableLinearManager *collectables;
	
	BOOL isPlayerFacingCollectable;
	
	GameMapView *mapView;
	NSTimer *introTimer;
	
	BOOL gameIsActive;
	
	NSMutableArray *monsters;
	NSMutableArray *walkTimes;
	
	float walkBPM;
	
	NSString *_gameEndMode;
	
	BOOL playerHasMoved;
	BOOL playerCanMove;
	
	NSTimer	*countdownTimer;
	CGFloat countdownCounter;
	
	CGFloat runningThresholdBPM;
	CGFloat trippingThresholdBPM;
	CGFloat trippingTimePenalty;
	
	NSString *tripSoundName;
	
	CGSize gamePlayAreaSize;
}

@property (nonatomic,retain) NSTimer *enterFrameTimer;
@property (nonatomic,assign) BOOL isLeftFoot;



- (void) birthGameLevel:(id)param;
- (void) clearGameLevel;
- (void) cleanup;

//- (void) onEnterFrame:(id)val;
- (void) updateSpatialisedSounds;
- (IBAction) didTapLeftFootButton:(id)sender;
- (IBAction) didTapRightFootButton:(id)sender;

- (void) rotatePlayer:(float)rotation;
- (void) rotatePlayerToFixedRotation:(float) rotation;
- (void) movePlayerForwardOneStep;

- (void) showDebug;

- (void) monsterNPC: (MonsterNPC *) monster didEatPlayerAtCGPoint:(CGPoint)pt;

- (void) calculateTempo;


- (void) startCountdownTimer;
- (void) updateCountdownTimer;
- (void) stopCountdownTimer;
- (void) runOutOfTime;

- (void) eatenByMonster:(NSString *)snd;

@end

