//
//  MainMenuViewController.h
//  SyP
//
//  Created by Adam Hoyle on 23/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MainMenuViewController : UITableViewController {

}

@end
