//
//  CslSpatialisedSound - initially based on CSL_Graph.mm -- CSL_iphone_test load/play methods
//
// Load the HRTF database from a resource named files.txt or HRTF_1028.dat.
// HRTF test player method sets up an HRTF DB and spatial source on a piano sample.
//		Loops at changing azimuth angles and distancesusing IRCAM head 1047 HRTF
//
//  Created by charlie on 8/21/09.
//  Copyright 2009 One More Muse. All rights reserved.
//	Updated for HRTF Binaural Panner, 0909 by STP.
//	

#import "CslSpatialisedSound.h"

// the CSL C++ stuff can be included in the mm file

#include "CSL_Includes.h"
#include "SpatialAudio.h"
#include "Binaural.h"
#include "iphoneIO.h"

#define kSoundThreadUpdateInterval			(1.0/50) // movement updates per second
#define kMessageType_Init					0
#define kMessageType_NewSound				1
#define kMessageType_ListenerPositionUpdate 2
#define kMessageType_Terminate				3
#define kMessageType_ChangePosition			4
#define kMessageType_NewArrayOfSounds		5
#define POS_THRESH		0.5f			// angular distance (in radians) for rear/center processing

@implementation CslSpatialisedSound

@synthesize isActive;
@synthesize xPos;
@synthesize zPos;

using namespace csl;

// Globals (exposed for access by other threads)

extern Spatializer * gPanner;	// the spatial panner

- (id) init
{
	if (self = [super init]) {
		pingTotal = 0;
		pTheta = 0;
		pDist = 5;
		_hasMoved = YES;
		source = nil;
		soundfile = nil;
	}
    return self;
}

- (void) dealloc
{
	NSLog(@"[CslSpatialisedSound dealloc]");
	[super dealloc];
}

#pragma mark ActorList thread implementation

// should be removed

- (void) createThread:(NSMutableDictionary *)prefs {
	// Spawn a new actor thread. This will return a process instance which may be used
	// to deliver messages the new actor.
	
	NSLog(@"[CslSpatialisedSound createThread] about to create thread");
	[self createEmptyThread];
	
	NSLog(@"[CslSpatialisedSound createThread] about to send init message to thread");
	
	[prefs setObject:[NSNumber numberWithInt:kMessageType_Init] forKey:@"type"];
	NSDictionary *immuteablePrefs = [NSDictionary dictionaryWithDictionary:prefs]; 
				// create an immutable version for thread safe
	
	//[self createMessageWithSubject:@"" andPayload:prefs];
	[cslActor send:[PLActorMessage messageWithObject:immuteablePrefs]];
	
	// Send a simple message to the actor.
	//[proc send: [PLActorMessage messageWithObject: @"Hello"]];
	
	// Wait for the echo
	//PLActorMessage *message = [PLActorKit receive];
	
	NSLog(@"[CslSpatialisedSound createThread] finished");
}

- (void) createEmptyThread
{
	id<PLActorProcess> proc = [PLActorKit spawnWithTarget:self selector: @selector(actorListThreadMain:)];
	cslActor = [proc retain];
}

#pragma mark main thread

- (void) playerPositionHasChanged:(CGPoint)position andAngle:(CGFloat)theAngle
{
	if (cslActor){
		NSArray *objects = [NSArray arrayWithObjects:[NSNumber numberWithInt:kMessageType_ListenerPositionUpdate],
													 [NSValue valueWithCGPoint:position],
													 [NSNumber numberWithFloat:theAngle],
													 nil];
		NSArray *keys	 = [NSArray arrayWithObjects:@"type", @"location",@"angle",nil];
		NSDictionary *dict = [NSDictionary dictionaryWithObjects:objects forKeys:keys];
		[cslActor send:[PLActorMessage messageWithObject:dict]];
	}
}

- (void) changeSoundFile:(NSString *)newSoundFile
{
	if (cslActor){
		NSArray *objects = [NSArray arrayWithObjects:[NSNumber numberWithInt:kMessageType_NewSound],
							newSoundFile,
							nil];
		NSArray *keys	 = [NSArray arrayWithObjects:@"type", @"sound",nil];
		NSDictionary *dict = [NSDictionary dictionaryWithObjects:objects forKeys:keys];
		[cslActor send:[PLActorMessage messageWithObject:dict]];
	}
}

- (void) playArrayOfSoundFiles:(NSArray *)arr
{
	if (cslActor){
		NSArray *snds = [NSArray arrayWithArray:arr]; // just to make sure 'arr' isn't mutable
		NSArray *objects = [NSArray arrayWithObjects:[NSNumber numberWithInt:kMessageType_NewArrayOfSounds],
							snds,
							nil];
		NSArray *keys	 = [NSArray arrayWithObjects:@"type", @"soundArray",nil];
		NSDictionary *dict = [NSDictionary dictionaryWithObjects:objects forKeys:keys];
		[cslActor send:[PLActorMessage messageWithObject:dict]];
	}
}

- (void) updateLocation:(CGPoint)pt
{
	if (cslActor){
		NSArray *objects = [NSArray arrayWithObjects:[NSNumber numberWithInt:kMessageType_ChangePosition],
							[NSValue valueWithCGPoint:pt],
							nil];
		NSArray *keys	 = [NSArray arrayWithObjects:@"type", @"location",nil];
		NSDictionary *dict = [NSDictionary dictionaryWithObjects:objects forKeys:keys];
		[cslActor send:[PLActorMessage messageWithObject:dict]];
	}
}

- (void) cleanup
{
	if (cslActor){
		NSArray *objects = [NSArray arrayWithObjects:[NSNumber numberWithInt:kMessageType_Terminate],
							nil];
		NSArray *keys	 = [NSArray arrayWithObjects:@"type",nil];
		NSDictionary *dict = [NSDictionary dictionaryWithObjects:objects forKeys:keys];
		[cslActor send:[PLActorMessage messageWithObject:dict]];
	}
}

#pragma mark spawned thread

- (void) actorListThreadMain:(id) param {
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	PLActorMessage *message;
	//NSDictionary* dict;
	
	[self setIsActive:YES];
	
	NSLog(@"[CslSpatialisedSound actorListThreadMain]");
	
	// Loop forever, receiving messages
	//while ((message = [PLActorKit receive]) != nil) {
	while ([self isActive]){	
		
		// get all of the messages in the buffer
		// @TODO - stop this caning the processor if there are loads of messages being sent
		while ([PLActorKit receive:&message withTimeout:0] == YES) // no timeout means fetch immediately
		{
			// do something with message here.
			[self processIncomingMessage:[message object]];
		} 
		
		// Flush the autorelease pool through every loop iteration
		[pool release];
		pool = [[NSAutoreleasePool alloc] init];
		
		// check we have a soundfile (just tracking the c++ var being cool wasn't working)
		if (soundLoaded){
			CASoundFile *sndfile = (CASoundFile *)soundfile;
			if (sndfile){
				// do any soundfile changes here
				
				if (!sndfile->isActive()){
					//sndfile->trigger();
					// this is the sequenced sound functionality
					// eg being able to specify an intro and loop snd
					[self processNextSequencedSoundFile];
				}
			}
		}
		
		// sleep for a bit (hopefully this will stop us caning the processor)
		sleepSec(kSoundThreadUpdateInterval);
	}
	
	NSLog(@"[CslSpatialisedSound actorListThreadMain] finished");
	
	[pool release];
}

- (void) processIncomingMessage:(NSDictionary *)dict
{
	NSString *sndFile;
	CGPoint location;
	NSNumber *angle;
	
	// this should be inside the thread
	int type = [[dict objectForKey:@"type"] intValue];
	//NSLog(@"[CslSnd processIncomingMessage] %i",type);
	switch (type) {
			
		// Process Initialisation
		case kMessageType_Init :
			// set the sound file MUST be done before the location
			sndFile = [dict objectForKey:@"sound"];
			if (sndFile){
				[self processNewSoundFile:sndFile looping:YES];
			}
			
			CGPoint pt;
			// set the location
			pt = [(NSValue *)[dict objectForKey:@"location"] CGPointValue];
			
			[self setXPos:[NSNumber numberWithFloat:pt.x]];
			[self setZPos:[NSNumber numberWithFloat:pt.y]];
			// setting it as a CGPoint
			//[NSValue valueWithCGPoint:pt];
			
			
			NSLog(@"[CslSpatialisedSound processIncomingMessage] INIT sndFile=%@ location=(%0.2fx%0.2f)",
					sndFile,pt.x,pt.y);
			
			break;
			
		// Process New Sound
		case kMessageType_NewSound:
			sndFile = [dict objectForKey:@"sound"];
			if (sndFile){
				[self processNewSoundFile:sndFile looping:YES];
			}
			break;
			
		case kMessageType_NewArrayOfSounds:
			sndfileArray = [[dict objectForKey:@"soundArray"] retain];
			sndfileCounter = 0;
			[self processNextSequencedSoundFile];
			
			break;
		
		case kMessageType_ListenerPositionUpdate:			
			
			location = [(NSValue *)[dict objectForKey:@"location"] CGPointValue];
			//playerTheta = (CGFloat)[(NSNumber *)[dict objectForKey:@"angle"] floatValue];
			
			
			//NSLog(@"[CSLSnd processIncomingMessage] LISTENER_MOVE angle='%0.2f'",playerTheta);
			
			//[self processNewListenerLocation:location andAngle:playerTheta];
			
			angle = (NSNumber *)[dict objectForKey:@"angle"];
			[self processNewListenerLocation:location andAngle:angle];
			
			break;
			
		case kMessageType_ChangePosition:
			
			location = [(NSValue *)[dict objectForKey:@"location"] CGPointValue];
			
			[self processNewLocation:location];
			
			break;
		
		case kMessageType_Terminate:
			
			[self removeSoundIfExists];
			
			break;
			
		// No Currently Known Matches
		default:
			NSLog(@"[CslSpatialisedSound] processIncomingMessage - unknown type '%i'",type);
			break;
			
	}
}

// method to change the current sound that this instance manages.
- (void) processNewSoundFile:(NSString *)newSoundFileName looping:(BOOL)loop
{
	NSLog(@"[CslSpatialisedSound processNewSoundFile] %@",newSoundFileName);
	// if there is an existing sound file, then remove it
	[self removeSoundIfExists];
	
	if (![newSoundFileName isEqual:@""]){
		// now get the sound file
		NSBundle * bundle = [NSBundle mainBundle];
		NSString *filename = [bundle pathForResource:newSoundFileName ofType:@"caf"];
		// get its name for c++
		const char * sampName = [filename cStringUsingEncoding: NSASCIIStringEncoding];
		// open and read the sound file
		CASoundFile *_sndfile = new CASoundFile(sampName);
		_sndfile->openForRead();
		_sndfile->dump();
		if (_sndfile->channels() != 1) {
			NSLog(@"[CslSpatialisedSound processNewSoundFile] convert snd file channels = %d for %@", _sndfile->channels(),newSoundFileName);
			_sndfile->mergeToMono();
		}
		soundfile = _sndfile;

		// make the sound file "positionable"
		SpatialSource * src = new SpatialSource(*_sndfile);
		gPanner->addSource(*src);			// Add the sound source to the Panner
		source = src;

		// should we loop the soundfile or not?
		if (loop){
			NSLog(@"setting up file to loop (%@)",filename);
			_sndfile->setIsLooping(true);
		} else {
			NSLog(@"setting up file to NOT loop (%@)",filename);
			_sndfile->setIsLooping(false); // just to be on the safe side (default shld be to not loop)
		}
		_sndfile->trigger();				// start it playing
		
		soundLoaded = YES;
		NSLog(@"[CslSpatialisedSound processNewSoundFile] added new sound '%@.caf'",newSoundFileName);
	}
	//NSLog(@"[cslSnd processNewSoundFile] completed");
}


- (void) processNextSequencedSoundFile
{
	int max = [sndfileArray count];
	if (sndfileCounter < max){
		NSString *asnd = [sndfileArray objectAtIndex:sndfileCounter];
		
		if (sndfileCounter == (max-1)){
						// make the last sound loop.
			[self processNewSoundFile:asnd looping:YES];
		} else {
			[self processNewSoundFile:asnd looping:NO];
		}
		
		sndfileCounter += 1;
	}
}

- (void) removeSoundIfExists
{
	if (soundLoaded){
		SpatialSource * src = (SpatialSource *)source;
		CASoundFile * sndfile = (CASoundFile *)soundfile;
//		NSLog(@"[CslSpatialisedSound removeSoundIfExists '%@']", sndfile->path().c_str());
		
		if (sndfile){
			sndfile->setToEnd(); // does this stop the file playing?
		} else {
			NSLog(@"[CslSpatialisedSound removeSoundIfExists] couldn't access sndfile, but source exists");
			goto flee;
		}
		
		gPanner->removeSource(*src);

		delete src;
		delete sndfile;
flee:
		source = 0;
		soundfile = 0;
		soundLoaded = NO;
	}	
}

//- (void) processNewListenerLocation:(CGPoint)location andAngle:(CGFloat)playerTheta
- (void) processNewListenerLocation:(CGPoint)location andAngle:(NSNumber *)angle
{
	playerTheta = [angle floatValue];
	//NSLog(@"[CslSnd processNewListenerLocation] angle='%0.2f'",playerTheta);
	
	playerLocation = location;
	
	[self updateSpatialisation];
	
}

- (void) processNewLocation:(CGPoint) location
{
	[self setXPos:[NSNumber numberWithFloat:location.x]];
	[self setZPos:[NSNumber numberWithFloat:location.y]];
	
	[self updateSpatialisation];
}

- (void) updateSpatialisation
{
	if (soundLoaded){
		// because of c++ & obj-c not playing too well, we have to define variables as void* in
		// the header, so we do this here to be tidy.
		SpatialSource *src = (SpatialSource *)source;
	
		float playerX = playerLocation.x; //[[prefs objectForKey:@"xpos"] floatValue];
		float playerY = playerLocation.y; //[[prefs objectForKey:@"ypos"] floatValue];
		//float playerTheta = [[prefs objectForKey:@"angle"] floatValue];
		
		float myX = [[self xPos] floatValue];
		float myY = [[self zPos] floatValue];
		
		// time for some trigonometry
		// we need hyp & theta
		// SOH CAH TOA
		float adj = playerX - myX;
		float opp = playerY - myY;
		// this has got to be in rads
		float theta = atan((opp/adj));
		//theta -= playerTheta;
		
		// pythagoras time
		float dist = sqrt((opp*opp)+(adj*adj));
		
		pTheta = theta *(180.0f/M_PI); // convert theta from radians to degrees.
		pTheta -= playerTheta;
		if (pTheta < 0){
			pTheta += 360;
		} else if (pTheta > 360){
			pTheta -= 360;
		}
		// added by atom to correct angle offset
		pTheta += 180;
		if (pTheta > 360) pTheta -= 360;
		if (adj < 0) pTheta += 180;
		if (pTheta < 0){
			pTheta += 360;
		} else if (pTheta > 360){
			pTheta -= 360;
		}
		// end added by atom to correct angle offset
		pDist = (dist/10.0f);
		
		//NSLog(@"[CslSnd] updateSpatialisation azim='%0.2f' dist='%0.2f' (playerTheta='%0.2f' playerPos=%0.2fx%0.2f)",pTheta,pDist,playerTheta,playerX,playerY);
		
		// update the location of the source
		src->setPosition('s', pTheta, 0.0f, pDist);    //source->setPosition('s', gAzim, gElev, gDist);
	
	} else {
		NSLog(@"[CslSpatialisedSound] didn't update position because source was null (or not true)");
	}
}

/*
 // copied direct from Apple's examples
 // gonna try avoiding a RunLoop for now, at least until i see better docs for it.
 - (void) startThreadWithRunLoop
 {
 NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
 
 NSRunLoop* myRunLoop = [NSRunLoop currentRunLoop];
 
 // Create a run loop observer and attach it to the run loop.
 CFRunLoopObserverContext  context = {0, self, NULL, NULL, NULL};
 CFRunLoopObserverRef    observer = CFRunLoopObserverCreate(kCFAllocatorDefault,
 kCFRunLoopAllActivities, YES, 0, &myRunLoopObserver, &context);
 
 if (observer)
 {
 CFRunLoopRef    cfLoop = [myRunLoop getCFRunLoop];
 CFRunLoopAddObserver(cfLoop, observer, kCFRunLoopDefaultMode);
 }
 
 // Create and schedule the timer.
 [NSTimer scheduledTimerWithTimeInterval:0.1 target:self
 selector:@selector(doFireTimer:) userInfo:nil repeats:YES];
 
 NSInteger    loopCount = 10;
 do
 {
 // Run the run loop 10 times to let the timer fire.
 [myRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:1]];
 loopCount--;
 }
 while (loopCount);
 
 [pool release];
 }
 */

@end
