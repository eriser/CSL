//
//  FloorSpaceData.h
//  SyP
//
//  Created by Adam Hoyle on 21/10/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FloorSpaceData : NSObject {
	
	NSArray *leftFootSounds;
	NSArray *rightFootSounds;
	NSArray *leftFootFacingSounds;
	NSArray *rightFootFacingSounds;
	size_t leftFootPointer;
	size_t rightFootPointer;
	NSArray *floorRects; // contains CGRects
	NSString *triggerType;
	BOOL hasTriggered;
	
	NSArray *leftFootFastSounds;
	NSArray *rightFootFastSounds;
	NSArray *leftFootFacingFastSounds;
	NSArray *rightFootFacingFastSounds;
	
	BOOL _surfaceIsLoud;
}

@property (nonatomic,retain) NSArray *floorRects;
@property (nonatomic,retain) NSString *triggerType;

- (id) initWithArrayOfFloorRects:(NSArray *)spaces 
			   andLeftFootSounds:(NSArray *)leftFoot 
			  andRightFootSounds:(NSArray *)rightFoot 
		 andLeftFootFacingSounds:(NSArray *)leftFootFacing 
		andRightFootFacingSounds:(NSArray *)rightFootFacing
				 andLeftFootFast:(NSArray *)leftFootFast 
				andRightFootFast:(NSArray *)rightFootFast 
		   andLeftFootFacingFast:(NSArray *)leftFootFacingFast 
		  andRightFootFacingFast:(NSArray *)rightFootFacingFast;
- (BOOL) isPointWithinRects:(CGPoint) pt;
- (id) getLeftFootSound:(BOOL)isFast;
- (id) getRightFootSound:(BOOL)isFast;
- (id) getLeftFootSoundFacing:(BOOL)isFast;
- (id) getRightFootSoundFacing:(BOOL)isFast;
- (BOOL) isMonsterTrigger;
- (BOOL) isTimerTrigger;

@end
