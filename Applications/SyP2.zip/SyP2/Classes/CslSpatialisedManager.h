//
//  CslSpatialisedManager.h
//  SyP
//
//  Created by Adam Hoyle on 18/10/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//  

#import <Foundation/Foundation.h>
#import "CslSpatialisedSound.h"
#import "CslStereoSound.h"


@interface CslSpatialisedManager : NSObject {
	NSMutableDictionary *stereoSoundDict;
}

- (void) loadHRTF;
- (void) startCSL;

- (CslSpatialisedSound *) newSpatialisedSound;

- (CslStereoSound *) newStereoSound;
- (void) playSoundWithName:(NSString *)name;
- (void) playLoopingSoundWithName:(NSString *)name;
- (void) cleanup;

@end

@interface CslSpatialisedManager (Private)

- (CslStereoSound *) getSoundWithNameOrCreateIfItDoesntExist:(NSString *)name;
- (void) cleanupInactiveSounds;
- (void) removeAllStereoSounds;

@end
