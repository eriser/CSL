//
//  FloorSpaceData.m
//  SyP
//
//  Created by Adam Hoyle on 21/10/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import "FloorSpaceData.h"

@implementation FloorSpaceData

@synthesize floorRects;
@synthesize triggerType;

- (id) initWithArrayOfFloorRects:(NSArray *)spaces 
			   andLeftFootSounds:(NSArray *)leftFoot 
			  andRightFootSounds:(NSArray *)rightFoot 
		 andLeftFootFacingSounds:(NSArray *)leftFootFacing 
		andRightFootFacingSounds:(NSArray *)rightFootFacing
				 andLeftFootFast:(NSArray *)leftFootFast 
				andRightFootFast:(NSArray *)rightFootFast 
		   andLeftFootFacingFast:(NSArray *)leftFootFacingFast 
		  andRightFootFacingFast:(NSArray *)rightFootFacingFast
{
	if (self = [super init]) {
		// floorRects is an array of NSValues with CGPoints inside them.
		floorRects = [spaces retain];
		leftFootSounds   = [leftFoot retain];
		rightFootSounds  = [rightFoot retain];
		leftFootFacingSounds = [leftFootFacing retain];
		rightFootFacingSounds = [rightFootFacing retain];
		leftFootFastSounds = [leftFootFast retain];
		rightFootFastSounds = [rightFootFast retain];
		leftFootFacingFastSounds = [leftFootFacingFast retain];
		rightFootFacingFastSounds = [rightFootFacingFast retain];
		leftFootPointer  = 0;
		rightFootPointer = 0;
		triggerType = @"";
		_surfaceIsLoud = NO;
		//NSLog(@"[FloorSpaceData initWithArrayOfFloorRects]");
	}
	return self;
}

- (BOOL) isPointWithinRects:(CGPoint) pt
{
	
	for (size_t i=0; i<[floorRects count]; i++) {
		NSValue *val = (NSValue *)[floorRects objectAtIndex:i];
		CGRect arect = [val CGRectValue];
		//[NSValue valueWithCGRect:<#(CGRect)rect#>
		if (CGRectContainsPoint(arect,pt)){
			return YES;
		}
	}
	return NO;
}

/*
- (id) getFootSoundForLeft:(BOOL)isLeft isFacing:(BOOL)isFacing isFast:(BOOL)isFast
{
	NSString *direction = @"L";
	NSString *
	
}
*/

- (id) getLeftFootSound:(BOOL)isFast
{
	//AVAudioPlayer *avp = 
	if (isFast == YES){
		return [leftFootFastSounds objectAtIndex:leftFootPointer];
	} else {
		return [leftFootSounds objectAtIndex:leftFootPointer];
	}
}

- (id) getRightFootSound:(BOOL)isFast
{
	if (isFast == YES){
		return [rightFootFastSounds objectAtIndex:rightFootPointer];
	} else {
		return [rightFootSounds objectAtIndex:rightFootPointer];
	}
}

- (id) getLeftFootSoundFacing:(BOOL)isFast
{
	if (isFast == YES){
		return [leftFootFacingFastSounds objectAtIndex:leftFootPointer];
	} else {
		return [leftFootFacingSounds objectAtIndex:leftFootPointer];
	}
}

- (id) getRightFootSoundFacing:(BOOL)isFast
{
	if (isFast == YES){
		return [rightFootFacingFastSounds objectAtIndex:rightFootPointer];
	} else {
		return [rightFootFacingSounds objectAtIndex:rightFootPointer];
	}
}

- (BOOL) isMonsterTrigger
{
	if ([triggerType isEqual:@"oneoff"]){
		triggerType = @"";
		return YES;
	} else if ([triggerType isEqual:@"repeating"]){
		return YES;
	}
	return NO;
}

- (BOOL) isTimerTrigger
{
	if ([triggerType isEqual:@"timer"]){
		triggerType = @"";
		return YES;
	}
	return NO;
}

- (void) setSurfaceIsLoud:(BOOL) isLoud
{
	_surfaceIsLoud = isLoud;
}

- (BOOL) surfaceIsLoud
{
	return _surfaceIsLoud;
}

@end
