//
//  SypGameView.m
//  SyP
//
//  Created by Adam Hoyle on 02/10/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import "SypGameViewCPWipe.h"


@implementation SypGameViewCPWipe


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch* touch = [touches anyObject];
	
	//NSLog(@"[SypGameView] - touchesBegan - tapCount is %i there are %i touches ", [touch tapCount],[touches count]);
	//if ([touch tapCount] == 1){
	
	if ([touch tapCount] > 9){
		[swipeDelegate showDebug];
	}
	
	
	startTouchLocation = [touch locationInView:self];
	[swipeDelegate touchDidStartSwipe:startTouchLocation];
	
	//}
	//if ([touch tapCount] >= 2){
	/*
	[NSObject cancelPreviousPerformRequestsWithTarget:self];
	//}
	if ([touch tapCount] == 1){
		//NSLog(@"DoubleClickableScrollView - touchesBegan - scheduling 'processSingleTap'");
		[self performSelector:@selector(processSingleTap:) withObject:touches afterDelay:0.25f];
	}
	
	 */
	[super touchesBegan:touches withEvent:event];
}

//-(void)touchesMoved:
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch* touch = [touches anyObject];
	CGPoint currentTouchLocation = [touch locationInView:self];
	CGPoint locationRelativeToStart = CGPointMake(currentTouchLocation.x-startTouchLocation.x, currentTouchLocation.y-startTouchLocation.y);
	[swipeDelegate touchDidMoveRelativeToStart:locationRelativeToStart];
	
	
	[super touchesMoved:touches withEvent:event];
}

//- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	//UITouch* touch = [touches anyObject];
	//CGPoint endTouchLocation = [touch locationInView:self];
	
	/*
	// flip x & y cos we are running in landscape
	CGFloat yDistance = endTouchLocation.x - startTouchLocation.x;
	CGFloat xDistance = endTouchLocation.y - startTouchLocation.y;
	
	NSLog(@"[SypGameView] - touchesEnded - xDistance=%0.2f yDistance=%0.2f ",xDistance,yDistance);
	
	if (yDistance < 50.0f && yDistance > -50.0f){
		
		if (xDistance > 40.0f){
			// swipe was to the right
			NSLog(@"[SypGameView] didSwipeRight");
			[swipeDelegate touchViewDidSwipeRight:self];
		} else if (xDistance < -40.0f) {
			NSLog(@"[SypGameView] didSwipeLeft");
			[swipeDelegate touchViewDidSwipeLeft:self];
		}
		
	}
	 */
	[super touchesEnded:touches withEvent:event];
}



@end
