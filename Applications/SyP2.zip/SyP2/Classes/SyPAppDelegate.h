//
//  SyPAppDelegate.h
//  SyP
//
//  Created by Adam Hoyle on 28/09/2009.
//  Copyright Do-Tank 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataModel.h"
#import "MainMenuViewController.h"

@class SyPViewController;


@interface SyPAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SyPViewController *viewController;
	MainMenuViewController *menuController;
	DataModel *model;
	
	uint _gameLevel;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SyPViewController *viewController;
@property (nonatomic, retain) IBOutlet MainMenuViewController *menuController;

- (GameLevel *) getCurrentGameLevel;
- (void) chooseLevel:(NSInteger) intgr;
- (void) finishedLevel:(NSString *) reason;

@end

