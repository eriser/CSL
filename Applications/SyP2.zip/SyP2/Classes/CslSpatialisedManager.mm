//
//  CslSpatialisedManager.mm
//  SyP
//
//  Created by Adam Hoyle on 18/10/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import "CslSpatialisedManager.h"

// the CSL C++ stuff can be included in the mm file -- get it?
#include "CSL_Includes.h"
#include "SpatialAudio.h"
#include "Binaural.h"
#include "iphoneIO.h"

@implementation CslSpatialisedManager

using namespace csl;

// HRTF globals

bool doHRTF = true;				// HRTF vs Ambisonics flag

// Globals (exposed for access by other threads)

Spatializer * gPanner = 0;		// the spatial panner
Mixer * gOutMix = 0;			// master output mixer
iPhoneIO * gIO = 0;				// the IO driver object

// new complicated CSL graph
//		(removed; now in the CSL library)
// end complicated CSL graph

// Load the HRTF database from a resource named files.txt or HRTF_1028.dat

- (void) loadHRTF {
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	doHRTF = [defaults boolForKey:@"ambisonic_binaural_preference"];
	if (doHRTF)
		NSLog(@"[CslSpatialisedManager] loadHRTF - Binaural = true");
	else
		NSLog(@"[CslSpatialisedManager] loadHRTF - Binaural = false");

	//logMsg("Start CSL App");
	if ( ! doHRTF)
		return;
	// get the bundle, the HRTF DB resource name, and its string
	NSBundle * bundle = [NSBundle mainBundle];
	NSString * filename = [bundle pathForResource: @"HRTF_1047" ofType: @"dat"];
	const char * theName = [filename cStringUsingEncoding: NSASCIIStringEncoding];
	NSLog(@"[CslSpatialisedManager] Loading HRTF data from \"%s\"", theName);
	// reload the HRTF DB
	HRTFDatabase::Reload((char *) theName);
	// log the DB name & size
	HRTFDatabase::Database()->dump();
}

// Start the CSL IO and create a global Spatializer

- (void) startCSL {	
//	NSLog(@"[CslSpatialisedManager] startCSL");
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	doHRTF = [defaults boolForKey:@"ambisonic_binaural_preference"];
												// which spatialization mode to use?
	NSLog(@"[CslSpatialisedManager startCSL] creating panner");
	
#define USE_SIMPLE_PANNER						// testing -- use simple panner only 
#ifdef USE_SIMPLE_PANNER
	NSLog(@"[CslSpatialisedManager] panner mode is Simple");
	gPanner = new Spatializer(kSimple);			// Create a "simple" spatializer
#else
	if (doHRTF){
		NSLog(@"[CslSpatialisedManager] panner mode is HRTF");
		gPanner = new Spatializer(kBinaural);	// Create an HRTF spatializer
	} else {
		NSLog(@"[CslSpatialisedManager] panner mode is Ambisonic");
		SpeakerLayout::setDefaultSpeakerLayout(new HeadphoneSpeakerLayout);
		gPanner = new Spatializer(kAmbisonic);	// Create an Ambisonic spatializer
	}	
#endif
	gOutMix = new Mixer(2);						// master stereo output mixer
	NSLog(@"[CslSpatialisedManager] gOutMix = %x", gOutMix);
	gOutMix->addInput(*gPanner);				// add the panner to the output mix
//	gOutMix->scaleInput(*gPanner,  AMP_SCALE);

//	NSLog(@"[CslSpatialisedManager] creating gIO");
	gIO = new iPhoneIO(44100, 256, -1, -1, 0, 2);	// the global IO
	
//	NSLog(@"[CslSpatialisedManager] adding the mixer to the CSL root");
	gIO->setRoot(*gOutMix);						// pass the CSL mixer to the IO
	
//	NSLog(@"[CslSpatialisedManager] about to gIO->open");
	gIO->open();								// open the IO
	
//	NSLog(@"[CslSpatialisedManager] about to gIO->start");
	gIO->start();								// start the driver callbacks and it plays!

	stereoSoundDict = [[NSMutableDictionary alloc] initWithCapacity:1];
}

- (void) cleanup
{
	[self removeAllStereoSounds];
	if (gIO){
		gIO->stop();
		gIO->close();
		delete gPanner;
		delete gOutMix;
		delete gIO;
		gIO = nil;
	}
}

- (void) dealloc
{
	[self cleanup];
	[super dealloc];
}

- (CslSpatialisedSound *) newSpatialisedSound
{
	NSLog(@"[CslSpatialisedManager newSpatialisedSound]");
	CslSpatialisedSound *snd = [[CslSpatialisedSound alloc] init];
	return snd;
}

#pragma mark stero sound management

- (CslStereoSound *) newStereoSound
{
	NSLog(@"[CslSpatialisedManager newStereoSound]");
	CslStereoSound *snd = [[CslStereoSound alloc] init];
	return snd;
}

// 
- (void) playSoundWithName:(NSString *)name
{
	NSLog(@"[CslManager playSoundWithName:%@]",name);
	CslStereoSound *snd = [self getSoundWithNameOrCreateIfItDoesntExist:name];
	[snd playFromStart];
}

- (void) playLoopingSoundWithName:(NSString *)name
{
	CslStereoSound *snd = [self getSoundWithNameOrCreateIfItDoesntExist:name];
	[snd playLooping];
}

- (void) stopLoopingSoundWithName:(NSString *)name
{
	CslStereoSound *snd = [self getSoundWithNameOrCreateIfItDoesntExist:name];
	[snd stopSound];
}

- (void) removeAllStereoSounds
{
	[[stereoSoundDict allValues] makeObjectsPerformSelector:@selector(clearSound)];
	[stereoSoundDict removeAllObjects];
}

- (CslStereoSound *) getSoundWithNameOrCreateIfItDoesntExist:(NSString *)name
{
	CslStereoSound *snd;
	snd = [stereoSoundDict objectForKey:name];
	[self cleanupInactiveSounds];
	if (!snd){
		// @TODO - should get sounds from a pool perhaps
		snd = [self newStereoSound];
		[stereoSoundDict setObject:snd forKey:name];
		[snd setSound:name];
	}
	return snd;
}

- (void) cleanupInactiveSounds
{
	// get all of the sounds in order of last played
	//NSArray *sorted = [stereoSoundDict keysSortedByValueUsingSelector:@selector(compareLastPlayed:)];
	
	// @TODO - remove old sounds, and add them back to the pool
	
}

@end
