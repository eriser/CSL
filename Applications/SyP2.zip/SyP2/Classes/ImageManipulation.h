//
//  ImageManipulation.h
//  mugshot
//
//  Created by Adam Hoyle on 12/01/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface ImageManipulation : NSObject {

}
+ (CGContextRef) getContextWithSize:(CGSize)theSize;
+ (UIImage *) scaleImage:(UIImage *)img toSize:(CGSize)finalSize;
+ (UIImage *) scaleImage:(UIImage *)img toSize:(CGSize)finalSize withCropRect:(CGRect)cropRect respectFinalSizeAspectRatio:(BOOL)respectRatio;
+ (UIImage *) scaleAndRotateImage:(UIImage *)image maxResolution:(int)max;
+ (NSString *) base64EncodeNSData:(NSData *)srcData;

@end
