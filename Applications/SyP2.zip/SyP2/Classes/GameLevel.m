//
//  GameLevel.m
//  SyP
//
//  Created by Adam Hoyle on 17/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import "GameLevel.h"
#import "FloorSpaceData.h"
#import "MonsterNPC.h"
#import <AVFoundation/AVFoundation.h>


@implementation GameLevel


- (id) initWithDictionary:(NSDictionary *)dict
{
	if (self = [super init]){
		levelDict = [dict retain];
		
		// do some error checking to make sure it's a valid dictionary??
		
		
	}
	return self;
}

- (void)dealloc {
    [super dealloc];
	
	// release the level dictionary.
	[levelDict release];
}


- (BOOL) isValid
{
	if (levelDict){
		/*
		if ([levelDict objectForKey:@""]){
			
		}
		 */
		return YES;
	}
	return NO;
}

- (CGFloat) getPlayerRunBPM
{
	NSDictionary *dict = [levelDict objectForKey:@"Properties"];
	if (dict){
		NSNumber *val = [dict objectForKey:@"runBPM"];
		return [val floatValue];
	}
	NSLog(@"[GameLevel getPlayerRunBPM] - Properties entry wasn't valid");
	return 150.0; //CGPointMake(1.0f, 1.0f);
}


- (CGFloat) getPlayerTripBPM
{
	NSDictionary *dict = [levelDict objectForKey:@"Properties"];
	if (dict){
		NSNumber *val = [dict objectForKey:@"tripBPM"];
		return [val floatValue];
	}
	NSLog(@"[GameLevel getPlayerTripBPM] - Properties entry wasn't valid");
	return 220.0;
}

- (CGFloat) getTripTimePenalty
{
	NSDictionary *dict = [levelDict objectForKey:@"Properties"];
	if (dict){
		NSNumber *val = [dict objectForKey:@"tripTimePenalty"];
		return [val floatValue];
	}
	NSLog(@"[GameLevel getPlayerTripTimePenalty] - Properties entry wasn't valid");
	return 220.0;
}

- (NSString*) getTripSound
{
	NSDictionary *dict = [levelDict objectForKey:@"Properties"];
	if (dict){
		NSString *val = [dict objectForKey:@"tripSound"];
		return val;
	}
	NSLog(@"[GameLevel getTripSound] - Properties entry wasn't valid");
	return @"w_noise_a";
}


- (CGPoint) getPlayerStartPosition
{
	NSDictionary *dict = [levelDict objectForKey:@"Properties"];
	if (dict){
		NSNumber *start_x = [dict objectForKey:@"start_x"];
		NSNumber *start_y = [dict objectForKey:@"start_y"];
		//if (start_x && start_y){
		return CGPointMake([start_x floatValue]-1.0f, [start_y floatValue]-1.0f);
		//}
	}
	NSLog(@"[GameLevel getPlayerStartPosition] - Properties entry wasn't valid");
	return CGPointMake(1.0f, 1.0f);
}

- (CGFloat) getPlayerStartAngle
{
	NSDictionary *dict = [levelDict objectForKey:@"Properties"];
	if (dict){
		NSNumber *start_angle = [dict objectForKey:@"start_angle"];
		CGFloat angle = [start_angle floatValue];
		angle -= 90;
		if (angle < 0) angle += 360;
		return angle;
	}
	NSLog(@"[GameLevel getPlayerStartAngle] - Properties entry wasn't valid");
	return 0;
}

- (NSString *) getLevelBgSound
{
	NSString *ret = @"";
	NSDictionary *dict = [levelDict objectForKey:@"Properties"];
	if (dict){
		ret = [dict objectForKey:@"bgSound"];
	}
	return ret;
}

- (NSString *) getLevelBgMusic
{
	NSString *ret = @"";
	NSDictionary *dict = [levelDict objectForKey:@"Properties"];
	if (dict){
		ret = [dict objectForKey:@"bgMusic"];
	}
	return ret;
}

- (NSString *) getIntroSound
{
	NSString *ret = @"";
	NSDictionary *dict = [levelDict objectForKey:@"Properties"];
	if (dict){
		ret = [dict objectForKey:@"startLevelSound"];
	}
	return ret;
}

- (CGSize) getPlayAreaSize
{
	CGSize ret = CGSizeMake(1,1);
	NSDictionary *dict = [levelDict objectForKey:@"Properties"];
	if (dict){
		CGFloat w = [[dict objectForKey:@"width"] floatValue];
		CGFloat h = [[dict objectForKey:@"height"] floatValue];
		ret = CGSizeMake(w, h);
	}
	return ret;
}

- (int) getTotalCollectables
{
	NSArray *arr = [levelDict objectForKey:@"Collectables"];
	return [arr count];
}

- (NSDictionary *) getCollectableDict:(int) num
{
	NSArray *arr = [levelDict objectForKey:@"Collectables"];
	if (num < [arr count])
	{
		return [arr objectAtIndex:num];
	}
	return NULL;
}

- (int) getTotalMonsters
{
	NSArray *arr = [levelDict objectForKey:@"Monsters"];
	return [arr count];
}

- (NSDictionary *) getMonsterDict:(int) num
{
	NSArray *arr = [levelDict objectForKey:@"Monsters"];
	if (num < [arr count])
	{
		return [arr objectAtIndex:num];
	}
	return NULL;
}

// @TODO - make the system work with quiet and loud foot sounds
- (NSArray *) getArrayOfFloorSpaceDatas
{
	NSMutableArray *leftFoot;
	NSMutableArray *rightFoot;
	NSMutableArray *leftFootFacing;
	NSMutableArray *rightFootFacing;
	NSMutableArray *leftFootFast;
	NSMutableArray *rightFootFast;
	NSMutableArray *leftFootFacingFast;
	NSMutableArray *rightFootFacingFast;
	NSString *quietFootSnd;
	NSString *quietFootFacingSnd;
	NSString *fastFootSnd;
	NSString *fastFootFacingSnd;
	NSString *triggerType;
	FloorSpaceData *fsd;
	
	NSMutableArray *arr = [NSMutableArray arrayWithCapacity:1];
	NSArray *surfaces = (NSArray *)[levelDict objectForKey:@"Surfaces"];
	for(size_t i = 0;i<[surfaces count];i++)
	{
		// get a surface out of the prefs
		NSDictionary *aSurface = [surfaces objectAtIndex:i];
		// get the rects into an array
		NSArray *rects = [aSurface objectForKey:@"Rects"];
		NSMutableArray *floorRects = [NSMutableArray arrayWithCapacity:1];
		for(size_t j=0;j<[rects count];j++)
		{
			NSDictionary *aRect = [rects objectAtIndex:j];
			[floorRects addObject:[NSValue valueWithCGRect:CGRectMake([[aRect objectForKey:@"x"] floatValue]-1.0f,
																	  [[aRect objectForKey:@"y"] floatValue]-1.0f,
																	  [[aRect objectForKey:@"width"] floatValue],
																	  [[aRect objectForKey:@"height"] floatValue])
								   ]
			 ];
		}
		
		quietFootSnd = [aSurface objectForKey:@"slowFoot"];
		quietFootFacingSnd = [aSurface objectForKey:@"facingSlowFoot"];
		fastFootSnd = [aSurface objectForKey:@"fastFoot"];
		fastFootFacingSnd = [aSurface objectForKey:@"facingFastFoot"];
		
		// get the footstep sounds into an array
		leftFoot = [NSMutableArray arrayWithCapacity:1];
		[leftFoot addObject:[NSString stringWithFormat:@"%@L",quietFootSnd]];
		
		rightFoot = [NSMutableArray arrayWithCapacity:1];
		[rightFoot addObject:[NSString stringWithFormat:@"%@R",quietFootSnd]];
		
		leftFootFacing = [NSMutableArray arrayWithCapacity:1];
		[leftFootFacing addObject:[NSString stringWithFormat:@"%@L",quietFootFacingSnd]];
		
		rightFootFacing = [NSMutableArray arrayWithCapacity:1];
		[rightFootFacing addObject:[NSString stringWithFormat:@"%@L",quietFootFacingSnd]];
		
		// get the footstep sounds into an array
		leftFootFast = [NSMutableArray arrayWithCapacity:1];
		[leftFootFast addObject:[NSString stringWithFormat:@"%@L",fastFootSnd]];
		
		rightFootFast = [NSMutableArray arrayWithCapacity:1];
		[rightFootFast addObject:[NSString stringWithFormat:@"%@R",fastFootSnd]];
		
		leftFootFacingFast = [NSMutableArray arrayWithCapacity:1];
		[leftFootFacingFast addObject:[NSString stringWithFormat:@"%@L",fastFootFacingSnd]];
		
		rightFootFacingFast = [NSMutableArray arrayWithCapacity:1];
		[rightFootFacingFast addObject:[NSString stringWithFormat:@"%@L",fastFootFacingSnd]];
		
		
		fsd = [[FloorSpaceData alloc] initWithArrayOfFloorRects:floorRects 
											  andLeftFootSounds:leftFoot 
											 andRightFootSounds:rightFoot 
										andLeftFootFacingSounds:leftFootFacing 
									   andRightFootFacingSounds:rightFootFacing 
												andLeftFootFast:leftFootFast 
											   andRightFootFast:rightFootFast 
										  andLeftFootFacingFast:leftFootFacingFast 
										 andRightFootFacingFast:rightFootFacingFast];
		// add the trigger type
		// should be one of 'oneoff', 'repeat' or 'timer'
		triggerType = [aSurface objectForKey:@"TriggerType"];
		if (triggerType != nil){
			NSLog(@"[GameLevel] adding triggerType '%@' to a FloorSpaceData",triggerType);
			[fsd setTriggerType:triggerType];
		}
		
		BOOL loudSurface = [(NSNumber *)[aSurface objectForKey:@"loudSurface"] boolValue];
		if (loudSurface == YES){
			[fsd setSurfaceIsLoud:YES];
			
		}
		
		[arr addObject:fsd];
		
		
		
		
	}
	return arr;
}

@end
