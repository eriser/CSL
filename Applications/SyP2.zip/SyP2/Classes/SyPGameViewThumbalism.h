//
//  SyPGameViewThumbalism.h
//  SyP
//
//  Created by Adam Hoyle on 29/10/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SyPGameViewThumbalism : UIView {

}

@end
