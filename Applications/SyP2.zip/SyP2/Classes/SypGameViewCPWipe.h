//
//  SypGameView.h
//  SyP
//
//  Created by Adam Hoyle on 02/10/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface SypGameViewCPWipe : UIView {
	CGPoint startTouchLocation;
	IBOutlet id swipeDelegate;
}


@end
