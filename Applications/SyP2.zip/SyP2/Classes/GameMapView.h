//
//  GameMapView.h
//  SyP
//
//  Created by Adam Hoyle on 30/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GameMapView : UIView {
	//CGImageRef 
	//CGContextRef surfacesCanvas; // surfaces don't change, so cache this
	CGLayerRef surfacesLayer;
	CGContextRef itemsCanvas;
	
	CGFloat tileSize;
	CGSize gameDimensions;
}

- (id)initWithFrame:(CGRect)frame andGameSize:(CGSize)size;
- (void) renderSurfaces:(NSArray *)arr;
- (CGLayerRef) getCGLayerFromCGImage:(CGImageRef)img withContext:(CGContextRef)context;
- (void) updatePlayerLocation:(CGPoint)playerLoc andCollectableLocation:(CGPoint)collectableLoc andMonsterLocations:(NSArray *)monsterLocs;

@end
