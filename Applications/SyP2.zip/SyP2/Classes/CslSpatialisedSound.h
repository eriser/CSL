//
//  CslSpatialisedSound.h
//  SyP
//
//  Created by Adam Hoyle on 12/10/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import "ActorKit.h"

@interface CslSpatialisedSound : NSObject {
	BOOL isActive;
	NSNumber *xPos;
	NSNumber *zPos;
	void * source;  // SpatialSource
	void * soundfile; // CASoundFile
		
	NSMutableArray *sndfileArray;
	int sndfileCounter;
	BOOL isSequencingSndFiles;
	
	//NSMutableArray *sourceArray;
	CFArrayRef *sourceArray;

	NSThread *cslThread;
	
	id < PLActorProcess > cslActor;
	
	float pTheta;
	float pDist;
	int pingTotal;
	BOOL _hasMoved;
	
	// instead of trying to deduce if a c++ sound is loaded, 
	// we're tracking it with a BOOL instead.
	BOOL soundLoaded; 
	
	CGPoint playerLocation;
	CGFloat playerTheta;
}

@property (nonatomic,assign) BOOL isActive;
@property (nonatomic,retain) NSNumber *xPos;
@property (nonatomic,retain) NSNumber *zPos;
//@property (nonatomic,retain) CASoundFile * sndfile;
//@property (nonatomic,retain) SpatialSource * source;

//- (id) initWithPanner:(void *)panner andRevMix:(void *)rMix andFiltMix:(void *)fMix;
- (id) init;

- (void) createThread:(NSDictionary *)prefs;
- (void) createEmptyThread;

//- (void) startHRTFThreadWithPrefs:(NSDictionary *)prefs;
//- (void) updateSoundFromPlayerPosition:(NSDictionary *)prefs;
//- (void) playerPositionHasChanged:(CGPoint)position;
//- (void) ping:(NSString *)str;

- (void) playerPositionHasChanged:(CGPoint)position andAngle:(CGFloat)theAngle;

- (void) changeSoundFile:(NSString *)newSoundFile;
- (void) playArrayOfSoundFiles:(NSArray *)arr;
- (void) updateLocation:(CGPoint)pt;
- (void) cleanup;


@end

#pragma mark internal ActorKit thread stuff

@interface CslSpatialisedSound (Private)

- (void) processIncomingMessage:(NSDictionary *)dict;
- (void) processNewSoundFile:(NSString *)newSoundFileName looping:(BOOL)loop;
- (void) removeSoundIfExists;
- (void) processNextSequencedSoundFile;
- (void) processNewListenerLocation:(CGPoint)location andAngle:(NSNumber *)angle;
- (void) processNewLocation:(CGPoint) location;
- (void) updateSpatialisation;

@end

