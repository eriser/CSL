//
//  DataModel.m
//  SyP
//
//  Created by Adam Hoyle on 17/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import "DataModel.h"
#import "GameLevel.h"


@implementation DataModel



- (void) startPreparingModel
{
	[self getTableOfContents];
	if (levels){
		GameLevel *gl = [self getLevel:0];
		CGPoint pt = [gl getPlayerStartPosition];
		NSLog(@"level 1 playerstart is %0.1fx%0.1f",pt.x,pt.y);

	} else {
		//NSLog(@"");
	}

}

- (void) startBackgroundThread
{
	
}

- (void) getTableOfContents {
	
	NSString *errorDesc = nil;
	NSPropertyListFormat format;
	//NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    //NSString *documentsDirectory = [paths objectAtIndex:0];
	//NSString *plistPath = [documentsDirectory stringByAppendingPathComponent:@"level_toc.plist"];
	NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"level_toc" ofType:@"plist"];
	//
	NSData *plistXML = [[NSFileManager defaultManager] contentsAtPath:plistPath];
	NSDictionary *toc = (NSDictionary *)[NSPropertyListSerialization
										  propertyListFromData:plistXML
										  mutabilityOption:NSPropertyListMutableContainersAndLeaves
										  format:&format errorDescription:&errorDesc];
	//
	NSArray *t_levels = [[toc objectForKey:@"Levels"] retain];
	//NSLog("[DataModel] toc is '%@'",[toc description]);
	if (t_levels){
		NSLog(@"[DataModel] found %i levels in the toc",[t_levels count]);
		levels = t_levels; // do we need to retain this specifically?
	} else {
		NSLog(@"[DataModel] %i",[t_levels count]);
	}
}

- (GameLevel *) getLevel:(uint)lvl {
	if (lvl < [levels count]){
		NSString *levelfile = [[levels objectAtIndex:lvl] valueForKey:@"File"];
		
		NSString *errorDesc = nil;
		NSPropertyListFormat format;
		//NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
		//NSString *documentsDirectory = [paths objectAtIndex:0];
		//NSString *plistPath = [documentsDirectory stringByAppendingPathComponent:levelfile];
		NSString *plistPath = [[NSBundle mainBundle] pathForResource:levelfile ofType:@"plist"];
		//
		NSData *plistXML = [[NSFileManager defaultManager] contentsAtPath:plistPath];
		NSDictionary *data = (NSDictionary *)[NSPropertyListSerialization
											 propertyListFromData:plistXML
											 mutabilityOption:NSPropertyListMutableContainersAndLeaves
											 format:&format errorDescription:&errorDesc];
		//
		GameLevel *gl = [[GameLevel alloc] initWithDictionary:data];
		[gl autorelease];
		return gl;
	}
	return nil;
}

- (NSInteger) levelCount
{
	return [levels count];
}

- (NSString *) nameForLevel:(NSInteger)lvl
{
	NSString *levelfile = @"error!";
	if (lvl < [levels count]){
		levelfile = [[levels objectAtIndex:lvl] valueForKey:@"Name"];
	}
	return levelfile;	
}

@end
