//
//  MonsterNPC.m
//  SyP
//
//  Created by Adam Hoyle on 25/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import "MonsterNPC.h"

//#define kMaximumHearingDistance 50.0f

@implementation MonsterNPC

//@synthesize delegate;

- (id) initWithSpatialisedSound:(CslSpatialisedSound *)snd andDictionary:(NSDictionary *)dict
{
	if (self = [super init]){
		float xp = 0; //[[dict objectForKey:@"x"] floatValue];
		float yp = 0; //[[dict objectForKey:@"y"] floatValue];
		location = CGPointMake(xp, yp);
		
		stillSound = [dict objectForKey:@"stillSound"];
		awareSound = [dict objectForKey:@"awareSound"];
		patrolSound = [dict objectForKey:@"patrolSound"];
		chaseSound = [dict objectForKey:@"chaseSound"];
		notThereSound = [dict objectForKey:@"notThereSound	"];
		attackSound = [dict objectForKey:@"attackSound"];
		
		chasePlayer = [(NSNumber *)[dict objectForKey:@"chasePlayer"] boolValue];
		
		maxHearingDistance = [[dict objectForKey:@"hearingDistance"] floatValue];
		
		// set up the walking speed
		float walkBPM = [[dict objectForKey:@"walkingBPM"] floatValue];
		if (walkBPM > 0){
			walkSpeedInSeconds = 60.0f/walkBPM;
		} else {
			walkSpeedInSeconds = 60.0f/60.0f;
		}
		// set up the running speed
		CGFloat runBPM = [[dict objectForKey:@"runningBPM"] floatValue];
		if (!runBPM){
			NSLog(@"WARNING - Oi! Pete - there's no 'runningBPM' specified for Monster, so using walkingBPM!");
			runBPM = walkBPM;
		}
		if (runBPM > 0){
			runSpeedInSeconds = 60.0f/runBPM;
		} else {
			runSpeedInSeconds = 60.0f/60.0f;
		}
		
		// get the path from the preferences.
		// @TODO - we shouldn't really trust this to be full of correct information - should do some analysis on it really.
		NSArray *_pathDetails = [dict objectForKey:@"path"];
		
		pathDetails = [[NSMutableArray arrayWithCapacity:0] retain];
		NSDictionary *pathItm;
		if (_pathDetails != nil){
			
			for (int i=0; i<[_pathDetails count]; i++) {
				pathItm = [_pathDetails objectAtIndex:i];
				if ([pathItm objectForKey:@"x"] != nil && [pathItm objectForKey:@"y"] != nil && [pathItm objectForKey:@"pause"] != nil){
					[pathDetails addObject:pathItm];
				} else {
					NSLog(@"MonsterNPC - Invalid Path Element within Monster Path (item #%i/%i)",(i+1),[_pathDetails count]);
				}
			}
			
			// if there are items in the path, then ignore the x & y properties
			if ([pathDetails count] > 0){
				NSDictionary *firstItm = [pathDetails objectAtIndex:0];
				xp = [[firstItm objectForKey:@"x"] floatValue];
				yp = [[firstItm objectForKey:@"y"] floatValue];
				location = CGPointMake(xp, yp);
			}
			
		} else {
			NSLog(@"MonsterNPC - path not defined AWOOOGA AWOOGA");
			pathDetails = [NSArray array];
		}
		NSLog(@"MonsterNPC - path has %i points",[pathDetails count]);
		
		
		cslSnd = snd;
		isActive = YES;
		[cslSnd updateLocation:location];
		[self activate];
		
		
		pathPointer = -1;
		[self queueNextWalkDestination];
		
	}
	return self;
}

- (void) dealloc
{
	[self deactivate];
	[super dealloc];
}

- (NSString *)attackSoundName
{
	return attackSound;
}

/**
 * Set the jukebox delegate.
 */
- (void) setDelegate: (id<MonsterDelegate>) delegate {
    _delegate = delegate;
}


- (void) activate
{
	isActive = YES;
	// [self startMoving];
	[cslSnd changeSoundFile:patrolSound];
}

- (void) startMoving
{
	[self stopMoving];
	nextStepTimer = [NSTimer scheduledTimerWithTimeInterval:walkSpeedInSeconds 
													 target:self 
												   selector:@selector(onEnterFrame:) 
												   userInfo:nil 
													repeats:YES];
}

- (void) startRunning
{
	[self stopMoving];
	nextStepTimer = [NSTimer scheduledTimerWithTimeInterval:runSpeedInSeconds 
													 target:self 
												   selector:@selector(onEnterFrame:) 
												   userInfo:nil 
													repeats:YES];
}

- (void) startMovingInSeconds:(float) seconds
{
	/*
	 // timer is automatically retained/released by the runloop, so over managing is causing EXC_BAD_ACCESS errors :'(
	if (startWalkingTimer != nil){
		if ([startWalkingTimer isValid]){
			[startWalkingTimer invalidate];
		}
		startWalkingTimer = nil;
	}*/
	if (seconds > 0){
		startWalkingTimer = [NSTimer scheduledTimerWithTimeInterval:seconds
															 target:self 
														   selector:@selector(startMoving) 
														   userInfo:nil 
															repeats:NO];
	} else {
		[self startMoving];
	}
}

- (void) stopMoving
{
	if (nextStepTimer != nil){
		[nextStepTimer invalidate];
		nextStepTimer = nil;
	}
}

- (void) deactivate
{
	isActive = NO;
	[self stopMoving];
	if (cslSnd){
		[cslSnd changeSoundFile:@""];
	}
}

- (NSDictionary *) playerPositionHasChanged:(CGPoint)loc andAngle:(CGFloat)angle
{
	BOOL hasCollided = NO;
	if (isActive){
		//float msNow = [NSDate 
		
		
		lastPlayerLoc = loc;
		lastPlayerAngle = angle;
		hasCollided = [self checkPlayerPosition];
	}
	NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
						  [NSValue valueWithCGPoint:location],@"location",
						  [NSNumber numberWithFloat:hasCollided],@"collided",
						  attackSound,@"attackSound",
						  nil
						  ];
					   
	return dict;
}

- (BOOL) checkPlayerPosition
{
	float adj = lastPlayerLoc.x - location.x;
	float opp = lastPlayerLoc.y - location.y;
	float dist = sqrt((opp*opp)+(adj*adj));
	
	if (dist < 1.5f){
		// monster is in the player's face!
		// kill the player!!
		return YES;
	}
	return NO;
}

- (BOOL) monsterIsAlertedToCGPoint:(CGPoint)loc
{
	if (chasePlayer){
		//targetLocation = loc;
		CGFloat adj = loc.x - location.x;
		CGFloat opp = loc.y - location.y;
		CGFloat dist = sqrt((opp*opp)+(adj*adj));
		if (dist < maxHearingDistance){
			targetLocation = loc;
			if (isHeadingForTarget == NO){
				NSLog(@"[Monster] monster was alerted to sound");
				[self startRunning];
				[cslSnd changeSoundFile:chaseSound];
				isHeadingForTarget = YES;
			}
		} else {
			NSLog(@"[Monster] sound too far away to be alerted");
		}
	}
	return NO;
}

- (void) onEnterFrame:(id)param
{
	if (isActive){
		//if (isHeadingForTarget){
		// figure out how far away the target is and move towards it.
		float adj = targetLocation.x - location.x;
		float opp = targetLocation.y - location.y;
		float dist = sqrt((opp*opp)+(adj*adj));
		
		
		if (dist > 1.0f){
			// move closer to target position
			//float theta = atan((opp/adj));
			float theta = atan2(opp,adj);
			float hyp = 0.8f; // this should vary per monster prolly
			
			float nadj = sin(theta)*hyp;
			float nopp = cos(theta)*hyp;
			
			// we have to flip the adj & opp around - not sure why, but seems to work
			location.x += nopp;
			location.y += nadj;
			
		} else {
			// very close to destination, so just clamp values
			location = targetLocation;
			
			[self queueNextWalkDestination];
			
		}
		
		BOOL eaten = [self checkPlayerPosition];
		
		if (eaten){
			NSLog(@"player has been eaten by predator");
			[cslSnd changeSoundFile:@""];
			isHeadingForTarget = NO;
			[self stopMoving];
			
			[_delegate monsterNPC:self didEatPlayerAtCGPoint:location];
			
		}
		
		//NSLog(@"[MonsterNPC] heading for target %0.2f away (%0.2fx%0.2f)",dist,location.x,location.y);
		
		// we don't actually call update on the csl sound here
		// that happens in the Game Controller.
		[cslSnd updateLocation:location];
		//
		// update csl sound here
		// in some ways this could/should happen outside, but only this
		// sound needs to update, so that would be a waste
		// does mean this sound is likely to be updated more than necessary tho'
		[cslSnd playerPositionHasChanged:lastPlayerLoc andAngle:lastPlayerAngle];
		//}
		//NSLog(@"[MonsterNPC] - walk done");
	}
}

- (void) queueNextWalkDestination
{
	[self stopMoving];
	// only update if there is a path
	if ([pathDetails count] > 0){
		// if we're not heading for a target, then 
		if (isHeadingForTarget == NO){
			pathPointer += 1;
			if (pathPointer >= [pathDetails count]) pathPointer = 0;
		} 
		NSDictionary *pathInfo = [pathDetails objectAtIndex:pathPointer];
		float xp = [[pathInfo objectForKey:@"x"] floatValue];
		float yp = [[pathInfo objectForKey:@"y"] floatValue];
		float pause = 0.0f;
		// only delay the walk if we're not resuming from heading for a different target.
		if (isHeadingForTarget == NO){
			pause = [[pathInfo objectForKey:@"pause"] floatValue];
		}
		targetLocation = CGPointMake(xp, yp);
		
		[self startMovingInSeconds:pause];
	}
	// it's quite wasteful to re-trigger a sound that is already playing.
	if (isHeadingForTarget != NO){
		[cslSnd changeSoundFile:patrolSound];
	}
	isHeadingForTarget = NO;
	//
}


- (CGPoint) location
{
	return CGPointMake(location.x,location.y);
}


@end
