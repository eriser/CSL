//
//  GameLevel.h
//  SyP
//
//  Created by Adam Hoyle on 17/11/2009.
//  Copyright 2009 Do-Tank. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface GameLevel : NSObject {
	NSDictionary *levelDict;
}

- (id) initWithDictionary:(NSDictionary *)dict;
- (BOOL) isValid;
- (CGPoint) getPlayerStartPosition;
- (int) getTotalCollectables;
- (NSDictionary *) getCollectableDict:(int) num;
- (int) getTotalMonsters;
- (NSDictionary *) getMonsterDict:(int) num;
- (NSArray *) getArrayOfFloorSpaceDatas;
- (NSString *) getLevelBgSound;
- (NSString *) getLevelBgMusic;

- (CGFloat) getPlayerStartAngle;
- (CGFloat) getPlayerRunBPM;
- (CGFloat) getPlayerTripBPM;
- (CGFloat) getTripTimePenalty;
- (NSString*) getTripSound;
- (NSString *) getIntroSound;
- (CGSize) getPlayAreaSize;
@end
